<?php

$recipient = "putyouremailhere@yandex.com";
$botToken="2128842654:AAHzJ7xKj4L_oLdb8QwZzfpBTcOPTD1e3II";
$chatId= '-569233702';

?>